enum Stable { Alpha, Beta }
