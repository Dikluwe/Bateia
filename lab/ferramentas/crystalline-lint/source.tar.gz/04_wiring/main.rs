//! Crystalline Lineage
//! @prompt 00_nucleo/prompts/linter-core.md
//! @prompt-hash 93634380
//! @layer L4
//! @updated 2026-10-16

use crystalline_lint::entities::analysis_policy::ParseCounts;
use crystalline_lint::shell::cli::CheckContext;
use std::borrow::Cow;
use std::collections::HashSet;
use std::path::{Path, PathBuf};
use std::process;

use clap::{CommandFactory, FromArgMatches};
use rayon::prelude::*;

use crystalline_lint::contracts::citation_freshness::UnknownCitationFreshness;
use crystalline_lint::contracts::file_provider::{
    collect_walker_results, FileProvider, SourceError, SourceFile,
};
use crystalline_lint::contracts::language_parser::{LanguageParser, ParserSet};
use crystalline_lint::contracts::prompt_provider::PromptProvider;
use crystalline_lint::contracts::prompt_reader::PromptReader;
use crystalline_lint::contracts::prompt_snapshot_reader::PromptSnapshotReader;
use crystalline_lint::entities::hash_pair::{BijectivePair, PairSnapshot};
use crystalline_lint::entities::l1_allowed_external::{L1AllowedExternal, L1AllowedExternalSet};
use crystalline_lint::entities::parsed_file::{ParsedFile, PublicInterface, WiringConfig};
use crystalline_lint::entities::project_index::{LocalIndex, ProjectIndex};
use crystalline_lint::entities::refinement::{
    compare_refinement, ArtifactFacts, ObservableValue, UnknownReason,
};
use crystalline_lint::entities::refinement_seal::{accepts, OracleKind, VerdictName};
use crystalline_lint::entities::violation::{Location, Violation, ViolationLevel};
use crystalline_lint::infra::c_parser::CParser;
use crystalline_lint::infra::citation_freshness::FsCitationFreshnessResolver;
use crystalline_lint::infra::config::CrystallineConfig;
use crystalline_lint::infra::config_init::{inspect_root, publish_config, serialize_config};
use crystalline_lint::infra::cpp_parser::CppParser;
use crystalline_lint::infra::crate_registry::CrateRegistry;
use crystalline_lint::infra::elixir_parser::ElixirParser;
use crystalline_lint::infra::git_refinement::{
    extract_revision_snapshot, extract_snapshot_from_revision_content, load_revision_with_git,
    require_self_contained_object_database, resolve_commit, GitRevisionError,
};
use crystalline_lint::infra::go_parser::GoParser;
use crystalline_lint::infra::hash_writer;
use crystalline_lint::infra::java_parser::JavaParser;
use crystalline_lint::infra::prompt_reader::FsPromptReader;
use crystalline_lint::infra::prompt_snapshot_reader::FsPromptSnapshotReader;
use crystalline_lint::infra::prompt_walker::FsPromptWalker;
use crystalline_lint::infra::py_parser::PyParser;
use crystalline_lint::infra::refinement_extractor::{
    extract_snapshot, load_observable_specs, load_observable_specs_from_bytes, serialize_snapshot,
    write_snapshot_atomic,
};
use crystalline_lint::infra::refinement_seal::{
    confined_read, load_manifest, read_manifest, receipt, semantic_manifest_sha256, serialize_seal,
    sha256, write_atomic, Seal, SealCounts,
};
use crystalline_lint::infra::refinement_snapshot::{
    load_contract, load_contract_from_bytes, load_snapshot,
};
use crystalline_lint::infra::rs_parser::RustParser;
use crystalline_lint::infra::snapshot_writer;
use crystalline_lint::infra::ts_parser::TsParser;
use crystalline_lint::infra::walker::FileWalker;
use crystalline_lint::infra::zig_parser::ZigParser;
use crystalline_lint::rules::infrastructure_error::{
    parse_error_to_violation, prompt_access_violation, source_error_to_violation,
};
use crystalline_lint::rules::pub_leak::L1Ports;
use crystalline_lint::rules::{
    alien_file, compound_guard, context_erasure, dangling_contract, decision_ownership,
    deep_pattern_nesting, external_type_in_contract, forbidden_import, impure_core,
    mergeable_decision_arms, multi_prompt_header, mutable_state_core, or_pattern_alternatives,
    orphan_prompt, prompt_drift, prompt_header, prompt_stale, provenance_inventory, pub_leak,
    quarantine_leak, range_pattern, semantic_field_loss, test_file, unsourced_constant,
    wildcard_saturation, wiring_logic_leak,
};
use crystalline_lint::shell::cli::{
    init_options_are_clean, validate_args, Cli, EnabledChecks, OutputFormat,
};
use crystalline_lint::shell::command::Command as ShellCommand;
use crystalline_lint::shell::config_init::{created, present, unknown_message, unsafe_message};
use crystalline_lint::shell::fix_hashes::{self, HashRewriter, TransactionalHashRewriter};
use crystalline_lint::shell::refinement::{self, RefinementOutputFormat};
use crystalline_lint::shell::update_snapshot::{self, SnapshotRewriter};
use crystalline_lint::{PromptOwnership, PromptOwnershipLayer};

fn select_git_executable() -> Result<PathBuf, String> {
    let path = std::env::var_os("PATH").ok_or("PATH is not set")?;
    for directory in std::env::split_paths(&path) {
        #[cfg(windows)]
        let candidates = [directory.join("git.exe"), directory.join("git")];
        #[cfg(not(windows))]
        let candidates = [directory.join("git")];
        for candidate in candidates {
            if candidate.is_file() {
                return candidate
                    .canonicalize()
                    .map_err(|error| format!("cannot resolve Git executable: {error}"));
            }
        }
    }
    Err("Git executable not found in PATH".to_string())
}

fn main() {
    let matches = Cli::command().get_matches();
    let init_options_clean = init_options_are_clean(&matches);
    let cli = Cli::from_arg_matches(&matches).unwrap_or_else(|error| error.exit());

    if cli.v19_reference.is_some() && cli.command.is_some() {
        if !cli.quiet {
            eprintln!("crystalline-lint: --v19-reference cannot be used with subcommands");
        }
        process::exit(2);
    }

    if let Some(ShellCommand::Init(args)) = &cli.command {
        use crystalline_lint::entities::config_init::{
            decide_init, detect_topology, ConfigDestinationState, InitPlan, InitReceipt,
            PublicationFailure,
        };

        if !init_options_clean {
            eprintln!("error: lint options cannot be used with 'init'");
            process::exit(2);
        }
        let inventory = inspect_root(&args.path).unwrap_or_else(|reason| {
            eprint!("{}", unsafe_message(&reason));
            process::exit(2)
        });
        let destination = args.path.join("crystalline.toml");
        let topology = if matches!(inventory.destination, ConfigDestinationState::Absent) {
            Some(detect_topology(&inventory.entries))
        } else {
            None
        };
        let receipt = match decide_init(inventory.destination, topology) {
            InitPlan::Create(topology) => {
                let bytes = serialize_config(&topology);
                match publish_config(&args.path, &bytes) {
                    Ok(_) => InitReceipt::Created,
                    Err(reason) => InitReceipt::PublicationFailed(PublicationFailure(reason)),
                }
            }
            InitPlan::RefusePresent => InitReceipt::RefusedPresent,
            InitPlan::RefuseUnsafe(reason) => InitReceipt::RefusedUnsafe(reason),
            InitPlan::RefuseUnknown(reason) => InitReceipt::RefusedUnknown(reason),
        };
        match receipt {
            InitReceipt::Created => {
                print!("{}", created(&destination));
                process::exit(0);
            }
            InitReceipt::RefusedPresent => {
                eprint!("{}", present(&destination));
                process::exit(1);
            }
            InitReceipt::RefusedUnsafe(reason) => {
                eprint!("{}", unsafe_message(&reason.0));
                process::exit(2);
            }
            InitReceipt::RefusedUnknown(reason) => {
                eprint!("{}", unknown_message(&reason));
                process::exit(2);
            }
            InitReceipt::PublicationFailed(reason) => {
                eprint!("{}", unsafe_message(&reason.0));
                process::exit(2);
            }
        }
    }

    if let Some(ShellCommand::SealRefinement(args)) = &cli.command {
        let manifest_bytes = read_manifest(&args.manifest).unwrap_or_else(|error| {
            eprintln!("crystalline-lint: refinement seal manifest error: {error}");
            process::exit(2)
        });
        let manifest = load_manifest(&manifest_bytes).unwrap_or_else(|error| {
            eprintln!("crystalline-lint: refinement seal manifest error: {error}");
            process::exit(2)
        });
        let manifest_hash = semantic_manifest_sha256(&manifest).unwrap_or_else(|error| {
            eprintln!("crystalline-lint: refinement seal manifest error: {error}");
            process::exit(2)
        });
        require_self_contained_object_database(&args.repository).unwrap_or_else(|error| {
            eprintln!("crystalline-lint: refinement seal repository error: {error}");
            process::exit(2)
        });
        let prompt_bytes =
            confined_read(&args.repository, &manifest.prompt).unwrap_or_else(|error| {
                eprintln!("crystalline-lint: refinement seal prompt error: {error}");
                process::exit(2)
            });
        if sha256(&prompt_bytes) != manifest.prompt_sha256 {
            eprintln!("crystalline-lint: refinement seal prompt hash mismatch");
            process::exit(2);
        }
        let contract_bytes =
            confined_read(&args.repository, &manifest.contract).unwrap_or_else(|error| {
                eprintln!("crystalline-lint: refinement seal contract error: {error}");
                process::exit(2)
            });
        if sha256(&contract_bytes) != manifest.contract_sha256 {
            eprintln!("crystalline-lint: refinement seal contract hash mismatch");
            process::exit(2);
        }
        let baseline_oid =
            resolve_commit(&args.repository, &manifest.baseline_oid).unwrap_or_else(|error| {
                eprintln!("crystalline-lint: refinement seal baseline error: {error}");
                process::exit(2)
            });
        if manifest.baseline_oid != baseline_oid {
            eprintln!("crystalline-lint: baseline_oid must be the complete canonical commit OID");
            process::exit(2);
        }
        let contract_source = manifest.contract.display().to_string();
        let specs = load_observable_specs_from_bytes(&contract_bytes, &contract_source)
            .unwrap_or_else(|error| {
                eprintln!("crystalline-lint: refinement seal contract error: {error}");
                process::exit(2)
            });
        let contract =
            load_contract_from_bytes(&contract_bytes, &contract_source).unwrap_or_else(|error| {
                eprintln!("crystalline-lint: refinement seal contract error: {error}");
                process::exit(2)
            });
        let mut receipts = Vec::with_capacity(manifest.oracles.len());
        for oracle in &manifest.oracles {
            let before_oid =
                resolve_commit(&args.repository, &oracle.before_ref).unwrap_or_else(|error| {
                    eprintln!(
                        "crystalline-lint: oracle `{}` before ref error: {error}",
                        oracle.id
                    );
                    process::exit(2)
                });
            let after_oid =
                resolve_commit(&args.repository, &oracle.after_ref).unwrap_or_else(|error| {
                    eprintln!(
                        "crystalline-lint: oracle `{}` after ref error: {error}",
                        oracle.id
                    );
                    process::exit(2)
                });
            let before = extract_revision_snapshot(&args.repository, &before_oid, &specs)
                .unwrap_or_else(|error| {
                    eprintln!(
                        "crystalline-lint: oracle `{}` before extraction error: {error}",
                        oracle.id
                    );
                    process::exit(2)
                });
            let after = extract_revision_snapshot(&args.repository, &after_oid, &specs)
                .unwrap_or_else(|error| {
                    eprintln!(
                        "crystalline-lint: oracle `{}` after extraction error: {error}",
                        oracle.id
                    );
                    process::exit(2)
                });
            let exhausted = |facts: &ArtifactFacts| {
                facts.observables.values().any(|value| {
                    matches!(
                        value,
                        ObservableValue::Unknown(UnknownReason::BudgetExhausted)
                    )
                })
            };
            if exhausted(&before) || exhausted(&after) {
                eprintln!(
                    "crystalline-lint: oracle `{}` exhausted the Git input budget",
                    oracle.id
                );
                process::exit(2);
            }
            let verdict = compare_refinement(&contract, &before, &after);
            let verdict_name = VerdictName::from(&verdict);
            if !accepts(oracle.kind, &verdict) {
                eprintln!(
                    "crystalline-lint: oracle `{}` expected {} but returned {}",
                    oracle.id,
                    oracle.kind.as_str(),
                    verdict_name.as_str()
                );
                process::exit(2);
            }
            receipts.push(receipt(
                oracle.id.clone(),
                oracle.kind,
                before_oid,
                after_oid,
                verdict_name,
            ));
        }
        receipts.sort_by(|a, b| a.id.cmp(&b.id));
        let positive_count = manifest
            .oracles
            .iter()
            .filter(|o| o.kind == OracleKind::Positive)
            .count();
        let negative_count = manifest
            .oracles
            .iter()
            .filter(|o| o.kind == OracleKind::Negative)
            .count();
        let unknown_count = manifest
            .oracles
            .iter()
            .filter(|o| o.kind == OracleKind::Unknown)
            .count();
        let seal = Seal {
            protocol_version: manifest.protocol_version,
            manifest_sha256: &manifest_hash,
            prompt_sha256: &manifest.prompt_sha256,
            contract_sha256: &manifest.contract_sha256,
            baseline_oid: &baseline_oid,
            contract_producer: &manifest.contract_producer,
            implementation_producer: &manifest.implementation_producer,
            verifier_producer: &manifest.verifier_producer,
            receipts: &receipts,
            counts: SealCounts {
                positive: positive_count,
                negative: negative_count,
                unknown: unknown_count,
            },
            mutation_score: "1.0",
            sealed: true,
        };
        let bytes = serialize_seal(&seal).unwrap_or_else(|error| {
            eprintln!("crystalline-lint: {error}");
            process::exit(2)
        });
        write_atomic(&args.output, &bytes).unwrap_or_else(|error| {
            eprintln!("crystalline-lint: {error}");
            process::exit(2)
        });
        process::exit(0);
    }

    if let Some(ShellCommand::Refine(args)) = &cli.command {
        let source = load_snapshot(&args.before).unwrap_or_else(|error| {
            eprintln!("crystalline-lint: refinement input error: {error}");
            process::exit(2);
        });
        let target = load_snapshot(&args.after).unwrap_or_else(|error| {
            eprintln!("crystalline-lint: refinement input error: {error}");
            process::exit(2);
        });
        let contract = load_contract(&args.contract).unwrap_or_else(|error| {
            eprintln!("crystalline-lint: refinement contract error: {error}");
            process::exit(2);
        });
        let verdict = compare_refinement(&contract, &source, &target);
        match args.format {
            RefinementOutputFormat::Text => print!("{}", refinement::format_text(&verdict)),
            RefinementOutputFormat::Sarif => println!("{}", refinement::format_sarif(&verdict)),
        }
        process::exit(refinement::exit_code(&verdict));
    }

    if let Some(ShellCommand::Snapshot(args)) = &cli.command {
        let specs = load_observable_specs(&args.contract).unwrap_or_else(|error| {
            eprintln!("crystalline-lint: snapshot contract error: {error}");
            process::exit(2);
        });
        let snapshot =
            extract_snapshot(&args.path, &args.artifact_id, &specs).unwrap_or_else(|error| {
                eprintln!("crystalline-lint: snapshot extraction error: {error}");
                process::exit(2);
            });
        let content = serialize_snapshot(&snapshot).unwrap_or_else(|error| {
            eprintln!("crystalline-lint: snapshot serialization error: {error}");
            process::exit(2);
        });
        write_snapshot_atomic(&args.output, &content).unwrap_or_else(|error| {
            eprintln!("crystalline-lint: snapshot write error: {error}");
            process::exit(2);
        });
        print!(
            "{}",
            refinement::format_snapshot_success(&args.output, snapshot.observables.len())
        );
        process::exit(0);
    }

    if let Some(ShellCommand::RefineRevisions(args)) = &cli.command {
        let specs = load_observable_specs(&args.contract).unwrap_or_else(|error| {
            eprintln!("crystalline-lint: refinement contract error: {error}");
            process::exit(2);
        });
        let contract = load_contract(&args.contract).unwrap_or_else(|error| {
            eprintln!("crystalline-lint: refinement contract error: {error}");
            process::exit(2);
        });
        let git_executable = select_git_executable().unwrap_or_else(|error| {
            eprintln!("crystalline-lint: refinement Git error: {error}");
            process::exit(2);
        });
        let logical_paths: Vec<PathBuf> = specs.iter().map(|spec| spec.file.clone()).collect();
        let before = load_revision_with_git(
            &git_executable,
            &args.repository,
            std::ffi::OsStr::new(&args.before_ref),
            &logical_paths,
        )
        .unwrap_or_else(|error| {
            if error == GitRevisionError::InvalidInput {
                eprintln!("crystalline-lint: before revision extraction error: path budget exceeded or invalid input");
                process::exit(2);
            }
            eprintln!(
                "crystalline-lint: before revision extraction error in self-contained repository: {error:?}"
            );
            process::exit(2);
        });
        let after = load_revision_with_git(
            &git_executable,
            &args.repository,
            std::ffi::OsStr::new(&args.after_ref),
            &logical_paths,
        )
        .unwrap_or_else(|error| {
            if error == GitRevisionError::InvalidInput {
                eprintln!("crystalline-lint: after revision extraction error: path budget exceeded or invalid input");
                process::exit(2);
            }
            eprintln!(
                "crystalline-lint: after revision extraction error in self-contained repository: {error:?}"
            );
            process::exit(2);
        });
        let source =
            extract_snapshot_from_revision_content(&before, &specs).unwrap_or_else(|error| {
                eprintln!("crystalline-lint: before revision projection error: {error}");
                process::exit(2);
            });
        let target =
            extract_snapshot_from_revision_content(&after, &specs).unwrap_or_else(|error| {
                eprintln!("crystalline-lint: after revision projection error: {error}");
                process::exit(2);
            });
        eprintln!(
            "crystalline-lint: comparing immutable Git objects {} -> {}; working tree ignored",
            before.oid, after.oid
        );
        let verdict = compare_refinement(&contract, &source, &target);
        match args.format {
            RefinementOutputFormat::Text => print!("{}", refinement::format_text(&verdict)),
            RefinementOutputFormat::Sarif => println!("{}", refinement::format_sarif(&verdict)),
        }
        process::exit(refinement::exit_code(&verdict));
    }

    // ── Arg validation ────────────────────────────────────────────────────────
    if let Err(e) = validate_args(&cli) {
        if !cli.quiet {
            eprintln!("crystalline-lint: {e}");
        }
        process::exit(1);
    }

    // Root confinement is structural and precedes parsing. Otherwise a root
    // failure can be multiplied into per-file errors or, for files without a
    // header, misreported as V1.
    if let Err(reason) = crystalline_lint::infra::prompt_io::validate_local_root(&cli.path) {
        let violations = vec![Violation {
            rule_id: "V0".into(),
            level: ViolationLevel::Fatal,
            message: format!("Falha ao validar raiz de prompts: {reason}"),
            location: Location {
                path: Cow::Owned(cli.path.clone()),
                line: 0,
                column: 0,
            },
        }];
        if cli.emit_resolution {
            if !cli.quiet {
                eprint!("{}", crystalline_lint::shell::cli::format_text(&violations));
            }
            process::exit(2);
        }
        if !cli.quiet {
            match cli.format {
                OutputFormat::Text => {
                    print!("{}", crystalline_lint::shell::cli::format_text(&violations));
                }
                OutputFormat::Sarif => {
                    println!(
                        "{}",
                        crystalline_lint::shell::cli::format_sarif(&violations)
                    );
                }
                OutputFormat::N16Summary => {
                    eprint!("{}", crystalline_lint::shell::cli::format_text(&violations));
                }
            }
        }
        process::exit(1);
    }

    let v19_reference = cli
        .v19_reference
        .as_ref()
        .map(|path| {
            let parent = path
                .parent()
                .filter(|p| !p.as_os_str().is_empty())
                .unwrap_or(Path::new("."));
            let name = path
                .file_name()
                .ok_or("reference must name a file".to_string())?;
            let bytes = crystalline_lint::infra::prompt_io::read_confined(
                parent,
                Path::new(name),
                crystalline_lint::shell::cli::V19_REFERENCE_MAX_BYTES,
            )?;
            crystalline_lint::shell::cli::parse_v19_reference(&bytes)
        })
        .transpose()
        .unwrap_or_else(|error| {
            if !cli.quiet {
                eprintln!("crystalline-lint: referência V19: {error}");
            }
            process::exit(2);
        });

    // ── Config ────────────────────────────────────────────────────────────────
    let config_path = if cli.config.is_relative() {
        cli.path.join(&cli.config)
    } else {
        cli.config.clone()
    };
    let config = CrystallineConfig::load_optional(&config_path)
        .unwrap_or_else(|error| {
            if !cli.quiet {
                eprintln!("crystalline-lint: config error: {error}");
            }
            process::exit(1);
        })
        .unwrap_or_else(|| {
            if matches.value_source("config") == Some(clap::parser::ValueSource::CommandLine) {
                if !cli.quiet {
                    eprintln!(
                        "crystalline-lint: explicit config does not exist: {}",
                        config_path.display()
                    );
                }
                process::exit(2);
            }
            CrystallineConfig::default()
        });

    // ── Phase 0: scan all prompts (sequential, before pipeline) ───────────────
    let nucleo_root = cli.path.clone();
    let enabled = EnabledChecks::from_cli(&cli.checks, cli.no_drift, cli.no_stale);

    let orphan_exceptions: std::collections::HashSet<String> =
        config.orphan_exceptions.keys().cloned().collect();
    let prompt_walker = FsPromptWalker::new(cli.path.clone(), orphan_exceptions);
    // Scan prompts only when V7 is enabled — avoids I/O when check is suppressed.
    // --emit-resolution não usa prompts e roda em workspaces arbitrários (sem
    // 00_nucleo): pula o scan para não abortar (instrumentação 0058).
    let all_prompts = if enabled.v7 && !cli.emit_resolution {
        match prompt_walker.scan() {
            Ok(ap) => Some(ap),
            Err(e) => {
                eprintln!("crystalline-lint: prompt scan error: {e:?}");
                process::exit(1);
            }
        }
    } else {
        None
    };

    // ── L1Ports from config ───────────────────────────────────────────────────
    let mut port_set: std::collections::HashSet<String> = config.l1_ports.keys().cloned().collect();
    for v in config.l1_ports.values() {
        port_set.insert(v.clone());
    }
    let l1_ports = L1Ports::new(port_set);

    // ── WiringConfig for V12 ──────────────────────────────────────────────────
    let v21_config = config.v21_rule_config();
    let citation_freshness = FsCitationFreshnessResolver::new(cli.path.clone(), 4 * 1024 * 1024);
    let semantic_levels = [
        ViolationLevel::Warning,
        ViolationLevel::Warning,
        ViolationLevel::Warning,
    ];

    let wiring_config = WiringConfig {
        allow_adapter_structs: config
            .wiring_exceptions
            .allow_adapter_structs
            .unwrap_or(true),
    };

    // ── L1AllowedExternalSet for V14 (por linguagem) ────────────────────────
    let l1_allowed = L1AllowedExternalSet {
        rust: L1AllowedExternal::for_rust(config.l1_allowed_for_language("rust")),
        python: L1AllowedExternal::for_python(config.l1_allowed_for_language("python")),
        typescript: L1AllowedExternal::for_typescript(config.l1_allowed_for_language("typescript")),
        c: L1AllowedExternal::for_c(config.l1_allowed_for_language("c")),
        cpp: L1AllowedExternal::for_cpp(config.l1_allowed_for_language("cpp")),
        zig: L1AllowedExternal::for_zig(config.l1_allowed_for_language("zig")),
        go: L1AllowedExternal::for_go(config.l1_allowed_for_language("go")),
        java: L1AllowedExternal::for_java(config.l1_allowed_for_language("java")),
        elixir: L1AllowedExternal::for_elixir(config.l1_allowed_for_language("elixir")),
    };

    // ── Crate registry (membro→camada + deps) para classificação ciente (0052) ─
    // Construído uma vez do workspace-alvo; vazio se não for projeto cargo (legado).
    let crate_registry = CrateRegistry::from_root(&cli.path, &config).unwrap_or_else(|error| {
        eprintln!("crystalline-lint: crate registry infrastructure error: {error}");
        process::exit(1)
    });

    // ── Instantiate L3 components ─────────────────────────────────────────────
    let shared_prompt_reader = std::sync::Arc::new(
        crystalline_lint::infra::prompt_reader::CachedPromptReader::new(FsPromptReader {
            nucleo_root: nucleo_root.clone(),
        }),
    );
    let shared_snapshot_reader = FsPromptSnapshotReader {
        nucleo_root: nucleo_root.clone(),
    };

    let parser = MultiParser {
        rust: RustParser::new(
            shared_prompt_reader.clone(),
            shared_snapshot_reader.clone(),
            config.clone(),
            crate_registry.clone(),
        ),
        ts: TsParser::new(
            shared_prompt_reader.clone(),
            shared_snapshot_reader.clone(),
            config.clone(),
            cli.path.clone(),
        ),
        py: PyParser::new(
            shared_prompt_reader.clone(),
            shared_snapshot_reader.clone(),
            config.clone(),
            cli.path.clone(),
        ),
        c: CParser::new(
            shared_prompt_reader.clone(),
            shared_snapshot_reader.clone(),
            config.clone(),
            cli.path.clone(),
        ),
        cpp: CppParser::new(
            shared_prompt_reader.clone(),
            shared_snapshot_reader.clone(),
            config.clone(),
            cli.path.clone(),
        ),
        zig: ZigParser::new(
            shared_prompt_reader.clone(),
            shared_snapshot_reader.clone(),
            config.clone(),
            cli.path.clone(),
        ),
        go: GoParser::new(
            shared_prompt_reader.clone(),
            shared_snapshot_reader.clone(),
            config.clone(),
            cli.path.clone(),
        ),
        java: JavaParser::new(
            shared_prompt_reader.clone(),
            shared_snapshot_reader.clone(),
            config.clone(),
            cli.path.clone(),
        ),
        elixir: ElixirParser::new(
            shared_prompt_reader.clone(),
            shared_snapshot_reader.clone(),
            config.clone(),
            cli.path.clone(),
        ),
    };
    let walker = FileWalker::new(cli.path.clone(), config.clone());

    // Collect source files and errors separately so ParsedFile<'a> can borrow
    // from source_files (zero-copy, ADR-0004). all_prompts is declared above
    // source_files so it outlives them — required for V7's check_orphans.
    let (source_files, source_errors) = collect_walker_results(walker.files());

    let (mut all_violations, all_parsed, project_index, parse_counts) = run_pipeline(
        &source_files,
        &source_errors,
        &parser,
        CheckContext {
            enabled: &enabled,
            l1_ports: &l1_ports,
            wiring_config: &wiring_config,
            l1_allowed: &l1_allowed,
            strict_dirs: &config.analysis.lineage.strict_directories,
            check_test_imports: config.check_test_imports.unwrap_or(false),
            wildcard_exceptions: &config.wildcard_exceptions,
            v21_config: &v21_config,
            semantic_levels: &semantic_levels,
            citation_freshness: &citation_freshness,
        },
    );

    // ── --emit-resolution (instrumentação 0058, fora do selo de veredito) ──────
    // Publica a resolução de todo import (incl. Unknown), sem emitir veredito de lint.
    if cli.emit_resolution {
        if !source_errors.is_empty() || all_parsed.len() != source_files.len() {
            if !cli.quiet {
                eprintln!("crystalline-lint: --emit-resolution blocked by incomplete analysis");
            }
            process::exit(2);
        }
        if cli.quiet {
            return;
        }
        // Resolve o nome de superfície ao crate real via o registry do linter
        // (renomeação por-membro), para o emit refletir a resolução do próprio linter.
        let resolve_crate = |path: &Path, seg: &str| -> String {
            crate_registry
                .owner_of(path)
                .and_then(|o| o.renames.get(seg).cloned())
                .unwrap_or_else(|| seg.to_string())
        };
        print!(
            "{}",
            crystalline_lint::shell::cli::format_resolution(&all_parsed, &resolve_crate)
        );
        return;
    }

    // ── V7/V8/V11 post-reduce ─────────────────────────────────────────────────
    let v7_level = config.level_for("V7", ViolationLevel::Warning);
    let v11_level = config.level_for("V11", ViolationLevel::Error);

    if enabled.v7 {
        if let Some(ref ap) = all_prompts {
            all_violations.extend(orphan_prompt::check_orphans(&project_index, ap, v7_level));
        }
    }
    if enabled.v8 {
        all_violations.extend(alien_file::check_aliens(&project_index));
    }
    if enabled.v11 {
        all_violations.extend(dangling_contract::check_dangling_contracts(
            &project_index,
            v11_level,
        ));
    }
    let prompt_ownerships = prompt_ownerships(&all_parsed);
    if enabled.v15 {
        all_violations.extend(crystalline_lint::check_prompt_ownership(&prompt_ownerships));
    }
    if enabled.v22 {
        all_violations.extend(provenance_inventory::check_inventory(
            &all_parsed,
            &v21_config,
        ));
    }
    if enabled.v26 {
        let audit = crystalline_lint::infra::nucleus::audit_project(&cli.path);
        for (path, message) in audit.issues {
            all_violations.push(Violation {
                rule_id: "V26".into(),
                level: ViolationLevel::Error,
                message,
                location: Location {
                    path: Cow::Owned(path),
                    line: 1,
                    column: 0,
                },
            });
        }
        for finding in
            crystalline_lint::rules::nucleus_integrity::check_graph(&audit.entries, &audit.usages)
        {
            all_violations.push(Violation {
                rule_id: "V26".into(),
                level: if finding.message.starts_with("orphan") {
                    ViolationLevel::Warning
                } else {
                    ViolationLevel::Error
                },
                message: finding.message,
                location: Location {
                    path: Cow::Owned(cli.path.join(finding.path)),
                    line: 1,
                    column: 0,
                },
            });
        }
        for file in &all_parsed {
            if file
                .prompt_header
                .as_ref()
                .is_some_and(|header| header.prompt_path.starts_with("00_nucleo/prompts/_nuclei/"))
            {
                all_violations.push(Violation {
                    rule_id: "V26".into(),
                    level: ViolationLevel::Error,
                    message: "production code cannot own a .toml nucleus through @prompt".into(),
                    location: Location {
                        path: Cow::Owned(file.path.to_path_buf()),
                        line: 1,
                        column: 0,
                    },
                });
            }
        }
    }

    // Sort before deduplication so the retained witness is deterministic even
    // though the parser map runs in parallel.
    crystalline_lint::shell::cli::sort_violations(&mut all_violations);

    let analysis_complete = source_errors.is_empty() && all_parsed.len() == source_files.len();
    if v19_reference.is_some() && !analysis_complete {
        if !cli.quiet {
            eprintln!("crystalline-lint: comparação V19 indisponível: análise incompleta");
            eprint!(
                "{}",
                crystalline_lint::shell::cli::format_text(&all_violations)
            );
        }
        process::exit(2);
    }
    let mut prompt_failures = HashSet::new();
    all_violations.retain(|violation| {
        if violation.rule_id == "V0" && violation.message.starts_with("Falha ao resolver prompt") {
            prompt_failures.insert(violation.message.clone())
        } else {
            true
        }
    });

    // ── Ordenação determinística ───────────────────────────────────────────────
    // Rayon não garante ordem — Fatal → Error → Warning, depois path, depois linha.
    crystalline_lint::shell::cli::sort_violations(&mut all_violations);

    if (cli.fix_hashes || cli.update_snapshot)
        && crystalline_lint::entities::analysis_policy::repair_is_blocked(&all_violations)
    {
        if !cli.quiet {
            eprintln!("crystalline-lint: repair blocked by incomplete analysis (V0/PARSE)");
        }
        process::exit(2);
    }

    // ── --fix-hashes branch ───────────────────────────────────────────────────
    if cli.fix_hashes {
        let rewriter = L3HashRewriter {
            nucleo_root: nucleo_root.clone(),
        };
        let nucleus_errors = all_violations
            .iter()
            .filter(|violation| {
                violation.rule_id == "V26"
                    && matches!(
                        violation.level,
                        ViolationLevel::Error | ViolationLevel::Fatal
                    )
                    && !violation.message.starts_with("stale nucleus pin ")
            })
            .count();
        if nucleus_errors > 0 {
            eprintln!(
                "crystalline-lint: --fix-hashes blocked by {nucleus_errors} V26 nucleus finding(s)"
            );
            process::exit(2);
        }
        let ownership_violations = crystalline_lint::check_prompt_ownership(&prompt_ownerships);
        if !ownership_violations.is_empty() {
            eprintln!(
                "crystalline-lint: --fix-hashes blocked by {} V15 ownership collision(s)",
                ownership_violations.len()
            );
            for violation in ownership_violations {
                eprintln!("{}", violation.message);
            }
            process::exit(2);
        }
        let entries = fix_hashes::plan_complete(&all_parsed, &rewriter).unwrap_or_else(|reason| {
            eprintln!("crystalline-lint: --fix-hashes blocked by incomplete preflight: {reason}");
            process::exit(2);
        });
        if entries
            .iter()
            .any(|entry| matches!(entry, fix_hashes::FixEntry::Unavailable { .. }))
        {
            if !cli.quiet {
                print!("{}", fix_hashes::format_plan(&entries));
            }
            eprintln!("crystalline-lint: --fix-hashes blocked by incomplete preflight");
            process::exit(2);
        }

        let pairs = entries
            .iter()
            .filter_map(|entry| match entry {
                fix_hashes::FixEntry::Ready {
                    source_path,
                    prompt_path,
                    old_hash,
                    new_hash,
                    source_hash,
                } => Some(hash_writer::prepare_pair(
                    &nucleo_root,
                    source_path,
                    prompt_path,
                    &nucleo_root.join(prompt_path),
                    old_hash,
                    new_hash,
                    source_hash,
                )),
                fix_hashes::FixEntry::Unavailable { .. } => None,
            })
            .collect::<Result<Vec<_>, _>>()
            .unwrap_or_else(|reason| {
                eprintln!("crystalline-lint: --fix-hashes preflight failed: {reason}");
                process::exit(2)
            });
        let transaction = fix_hashes::plan_bijective(&pairs, &rewriter).unwrap_or_else(|error| {
            eprintln!("crystalline-lint: --fix-hashes preflight failed: {error}");
            process::exit(2)
        });

        if cli.dry_run {
            if !cli.quiet {
                print!("{}", fix_hashes::format_plan(&entries));
            }
            return;
        }

        let unfixable = entries
            .iter()
            .filter(|e| matches!(e, fix_hashes::FixEntry::Unavailable { .. }))
            .count();
        let batch_result = fix_hashes::execute_bijective(&transaction, &rewriter, false);
        if !batch_result.is_complete() {
            eprintln!("crystalline-lint: --fix-hashes transaction failed: {batch_result:?}");
            process::exit(2);
        }
        fix_hashes::validate_bijective(&transaction, &rewriter).unwrap_or_else(|error| {
            eprintln!("crystalline-lint: --fix-hashes validation failed: {error}");
            process::exit(2)
        });
        let results = entries
            .iter()
            .map(|entry| match entry {
                fix_hashes::FixEntry::Unavailable {
                    source_path,
                    reason,
                } => fix_hashes::FixResult::Unavailable {
                    source_path: source_path.clone(),
                    reason: reason.clone(),
                },
                fix_hashes::FixEntry::Ready {
                    source_path,
                    prompt_path,
                    new_hash,
                    source_hash,
                    ..
                } => fix_hashes::FixResult::Applied {
                    source_path: source_path.clone(),
                    prompt_path: prompt_path.clone(),
                    new_hash: new_hash.clone(),
                    source_hash: source_hash.clone(),
                },
            })
            .collect::<Vec<_>>();

        // Re-run analysis to count remaining V5
        let remaining_v5 = {
            let fresh_prompt_reader = std::sync::Arc::new(
                crystalline_lint::infra::prompt_reader::CachedPromptReader::new(FsPromptReader {
                    nucleo_root: nucleo_root.clone(),
                }),
            );
            let reparser = MultiParser {
                rust: RustParser::new(
                    fresh_prompt_reader.clone(),
                    shared_snapshot_reader.clone(),
                    config.clone(),
                    crate_registry.clone(),
                ),
                ts: TsParser::new(
                    fresh_prompt_reader.clone(),
                    shared_snapshot_reader.clone(),
                    config.clone(),
                    cli.path.clone(),
                ),
                py: PyParser::new(
                    fresh_prompt_reader.clone(),
                    shared_snapshot_reader.clone(),
                    config.clone(),
                    cli.path.clone(),
                ),
                c: CParser::new(
                    fresh_prompt_reader.clone(),
                    shared_snapshot_reader.clone(),
                    config.clone(),
                    cli.path.clone(),
                ),
                cpp: CppParser::new(
                    fresh_prompt_reader.clone(),
                    shared_snapshot_reader.clone(),
                    config.clone(),
                    cli.path.clone(),
                ),
                zig: ZigParser::new(
                    fresh_prompt_reader.clone(),
                    shared_snapshot_reader.clone(),
                    config.clone(),
                    cli.path.clone(),
                ),
                go: GoParser::new(
                    fresh_prompt_reader.clone(),
                    shared_snapshot_reader.clone(),
                    config.clone(),
                    cli.path.clone(),
                ),
                java: JavaParser::new(
                    fresh_prompt_reader.clone(),
                    shared_snapshot_reader.clone(),
                    config.clone(),
                    cli.path.clone(),
                ),
                elixir: ElixirParser::new(
                    fresh_prompt_reader.clone(),
                    shared_snapshot_reader.clone(),
                    config.clone(),
                    cli.path.clone(),
                ),
            };
            let rewalker = FileWalker::new(cli.path.clone(), config.clone());
            let (re_files, re_errors) = collect_walker_results(rewalker.files());
            let v5_only = EnabledChecks {
                v1: false,
                v2: false,
                v3: false,
                v4: false,
                v5: true,
                v6: false,
                v7: false,
                v8: false,
                v9: false,
                v10: false,
                v11: false,
                v12: false,
                v13: false,
                v14: false,
                v15: false,
                v16: false,
                v17: false,
                v18: false,
                v19: false,
                v20: false,
                v21: false,
                v22: false,
                v23: false,
                v24: false,
                v25: false,
                v26: false,
                v27: false,
            };
            let (violations, _, _, _) = run_pipeline(
                &re_files,
                &re_errors,
                &reparser,
                CheckContext {
                    enabled: &v5_only,
                    l1_ports: &l1_ports,
                    wiring_config: &wiring_config,
                    l1_allowed: &l1_allowed,
                    strict_dirs: &config.analysis.lineage.strict_directories,
                    check_test_imports: config.check_test_imports.unwrap_or(false),
                    wildcard_exceptions: &config.wildcard_exceptions,
                    v21_config: &v21_config,
                    semantic_levels: &semantic_levels,
                    citation_freshness: &UnknownCitationFreshness,
                },
            );
            violations.iter().filter(|v| v.rule_id == "V5").count()
        };

        if !cli.quiet {
            print!(
                "{}",
                fix_hashes::format_results(&results, unfixable, remaining_v5)
            );
        }

        if remaining_v5 > 0 {
            process::exit(1);
        }
        return;
    }

    // ── --update-snapshot branch ──────────────────────────────────────────────
    if cli.update_snapshot {
        let rewriter = L3SnapshotWriter {
            nucleo_root: nucleo_root.clone(),
        };
        let entries = update_snapshot::plan(&all_violations, &all_parsed, &rewriter);

        if cli.dry_run {
            if !cli.quiet {
                print!("{}", update_snapshot::format_plan(&entries));
            }
            return;
        }

        let results = update_snapshot::execute(&entries, &rewriter, false);

        // Re-run to count remaining V6
        let remaining_v6 = {
            let reparser = MultiParser {
                rust: RustParser::new(
                    shared_prompt_reader.clone(),
                    shared_snapshot_reader.clone(),
                    config.clone(),
                    crate_registry.clone(),
                ),
                ts: TsParser::new(
                    shared_prompt_reader.clone(),
                    shared_snapshot_reader.clone(),
                    config.clone(),
                    cli.path.clone(),
                ),
                py: PyParser::new(
                    shared_prompt_reader.clone(),
                    shared_snapshot_reader.clone(),
                    config.clone(),
                    cli.path.clone(),
                ),
                c: CParser::new(
                    shared_prompt_reader.clone(),
                    shared_snapshot_reader.clone(),
                    config.clone(),
                    cli.path.clone(),
                ),
                cpp: CppParser::new(
                    shared_prompt_reader.clone(),
                    shared_snapshot_reader.clone(),
                    config.clone(),
                    cli.path.clone(),
                ),
                zig: ZigParser::new(
                    shared_prompt_reader.clone(),
                    shared_snapshot_reader.clone(),
                    config.clone(),
                    cli.path.clone(),
                ),
                go: GoParser::new(
                    shared_prompt_reader.clone(),
                    shared_snapshot_reader.clone(),
                    config.clone(),
                    cli.path.clone(),
                ),
                java: JavaParser::new(
                    shared_prompt_reader.clone(),
                    shared_snapshot_reader.clone(),
                    config.clone(),
                    cli.path.clone(),
                ),
                elixir: ElixirParser::new(
                    shared_prompt_reader.clone(),
                    shared_snapshot_reader.clone(),
                    config.clone(),
                    cli.path.clone(),
                ),
            };
            let rewalker = FileWalker::new(cli.path.clone(), config.clone());
            let (re_files, re_errors) = collect_walker_results(rewalker.files());
            let v6_only = EnabledChecks {
                v1: false,
                v2: false,
                v3: false,
                v4: false,
                v5: false,
                v6: true,
                v7: false,
                v8: false,
                v9: false,
                v10: false,
                v11: false,
                v12: false,
                v13: false,
                v14: false,
                v15: false,
                v16: false,
                v17: false,
                v18: false,
                v19: false,
                v20: false,
                v21: false,
                v22: false,
                v23: false,
                v24: false,
                v25: false,
                v26: false,
                v27: false,
            };
            let (violations, _, _, _) = run_pipeline(
                &re_files,
                &re_errors,
                &reparser,
                CheckContext {
                    enabled: &v6_only,
                    l1_ports: &l1_ports,
                    wiring_config: &wiring_config,
                    l1_allowed: &l1_allowed,
                    strict_dirs: &config.analysis.lineage.strict_directories,
                    check_test_imports: config.check_test_imports.unwrap_or(false),
                    wildcard_exceptions: &config.wildcard_exceptions,
                    v21_config: &v21_config,
                    semantic_levels: &semantic_levels,
                    citation_freshness: &UnknownCitationFreshness,
                },
            );
            violations.iter().filter(|v| v.rule_id == "V6").count()
        };

        if !cli.quiet {
            print!(
                "{}",
                update_snapshot::format_results(&results, remaining_v6)
            );
        }

        if remaining_v6 > 0 {
            process::exit(1);
        }
        return;
    }

    if cli.format == OutputFormat::N16Summary
        && (!source_errors.is_empty() || all_parsed.len() != source_files.len())
    {
        if !cli.quiet {
            eprint!(
                "{}",
                crystalline_lint::shell::cli::format_text(&all_violations)
            );
        }
        process::exit(2);
    }

    crystalline_lint::entities::analysis_policy::apply_policy(
        &mut all_violations,
        &all_parsed,
        &config.rule_policy(),
    );
    crystalline_lint::shell::cli::sort_violations(&mut all_violations);

    // ── Normal output ─────────────────────────────────────────────────────────
    let v19_comparison = v19_reference.as_ref().map(|reference| {
        crystalline_lint::shell::cli::compare_v19_reference(&all_violations, &cli.path, reference)
    });
    if !cli.quiet {
        let output = match cli.format {
            OutputFormat::Text => crystalline_lint::shell::cli::format_text_with_v19(
                &all_violations,
                v19_comparison.as_ref(),
            ),
            OutputFormat::Sarif => crystalline_lint::shell::cli::format_sarif_with_v19(
                &all_violations,
                &cli.path,
                enabled.v19,
                analysis_complete,
                v19_comparison.as_ref(),
            ),
            OutputFormat::N16Summary => {
                let stats = crystalline_lint::shell::n16_summary::collect_n16_stats(
                    &source_files,
                    &config.wildcard_exceptions,
                );
                crystalline_lint::shell::n16_summary::format_n16_summary(
                    &stats,
                    config.n16_min_sample_size(),
                )
            }
        };
        let output = if cli.analysis_scope {
            let errors = all_violations
                .iter()
                .filter(|finding| finding.rule_id == "V0")
                .count();
            let scope = crystalline_lint::shell::cli::analysis_scope(
                source_files.len(),
                errors,
                &all_parsed,
                crystalline_lint::shell::cli::ScopeSettings {
                    checks: &cli.checks,
                    parse_counts,
                    source_read_errors: source_errors.len(),
                    no_drift: cli.no_drift,
                    no_stale: cli.no_stale,
                    policy: &config.rule_policy(),
                    excluded_dirs: config.excluded.values().cloned().collect(),
                    excluded_files: config.excluded_files.values().cloned().collect(),
                },
            );
            crystalline_lint::shell::cli::format_with_scope(&output, &cli.format, scope)
        } else {
            output
        };
        print!("{output}");
    }

    // ── Exit code ─────────────────────────────────────────────────────────────
    if crystalline_lint::shell::cli::should_fail(&all_violations, &cli.fail_on) {
        process::exit(1);
    }
}

// ── MultiParser — L4 composition root ────────────────────────────────────────

/// Owns the concrete L3 adapters. Routing policy remains in the L1 `ParserSet`.
struct MultiParser {
    rust: RustParser<
        std::sync::Arc<crystalline_lint::infra::prompt_reader::CachedPromptReader<FsPromptReader>>,
        FsPromptSnapshotReader,
    >,
    ts: TsParser<
        std::sync::Arc<crystalline_lint::infra::prompt_reader::CachedPromptReader<FsPromptReader>>,
        FsPromptSnapshotReader,
    >,
    py: PyParser<
        std::sync::Arc<crystalline_lint::infra::prompt_reader::CachedPromptReader<FsPromptReader>>,
        FsPromptSnapshotReader,
    >,
    c: CParser<
        std::sync::Arc<crystalline_lint::infra::prompt_reader::CachedPromptReader<FsPromptReader>>,
        FsPromptSnapshotReader,
    >,
    cpp: CppParser<
        std::sync::Arc<crystalline_lint::infra::prompt_reader::CachedPromptReader<FsPromptReader>>,
        FsPromptSnapshotReader,
    >,
    zig: ZigParser<
        std::sync::Arc<crystalline_lint::infra::prompt_reader::CachedPromptReader<FsPromptReader>>,
        FsPromptSnapshotReader,
    >,
    go: GoParser<
        std::sync::Arc<crystalline_lint::infra::prompt_reader::CachedPromptReader<FsPromptReader>>,
        FsPromptSnapshotReader,
    >,
    java: JavaParser<
        std::sync::Arc<crystalline_lint::infra::prompt_reader::CachedPromptReader<FsPromptReader>>,
        FsPromptSnapshotReader,
    >,
    elixir: ElixirParser<
        std::sync::Arc<crystalline_lint::infra::prompt_reader::CachedPromptReader<FsPromptReader>>,
        FsPromptSnapshotReader,
    >,
}

impl LanguageParser for MultiParser {
    fn parse<'a>(
        &self,
        file: &'a SourceFile,
    ) -> Result<ParsedFile<'a>, crystalline_lint::contracts::parse_error::ParseError> {
        ParserSet {
            rust: &self.rust,
            typescript: &self.ts,
            python: &self.py,
            c: &self.c,
            cpp: &self.cpp,
            zig: &self.zig,
            go: &self.go,
            java: &self.java,
            elixir: &self.elixir,
        }
        .parse(file)
    }
}

// ── L4 adapter: HashRewriter (L3 hash_writer → L2 port) ──────────────────────

struct L3HashRewriter {
    nucleo_root: PathBuf,
}

impl HashRewriter for L3HashRewriter {
    fn read_header(&self, source_path: &Path) -> Option<(String, String)> {
        hash_writer::read_header(source_path)
    }

    fn compute_hash(&self, prompt_path: &str) -> Result<Option<String>, String> {
        // Reuse hash calculation logic from FsPromptReader (with size limits)
        match (FsPromptReader {
            nucleo_root: self.nucleo_root.clone(),
        })
        .read_hash(prompt_path)
        {
            crystalline_lint::contracts::prompt_reader::PromptHashResolution::Hash(hash) => Ok(Some(hash)),
            crystalline_lint::contracts::prompt_reader::PromptHashResolution::Missing => Ok(None),
            crystalline_lint::contracts::prompt_reader::PromptHashResolution::InfrastructureFailure { reason } => Err(reason),
        }
    }

    fn compute_source_hash(&self, source_path: &Path) -> Option<String> {
        hash_writer::compute_source_hash(source_path)
    }

    fn source_hash_matches(&self, prompt_path: &str, expected: &str) -> Result<bool, String> {
        hash_writer::source_hash_matches(&self.nucleo_root, prompt_path, expected)
    }

    fn write_hash(&self, source_path: &Path, new_hash: &str) -> Result<(), String> {
        hash_writer::write_hash(source_path, new_hash)
    }

    fn write_prompt_meta(&self, prompt_path: &str, code_hash: &str) -> Result<(), String> {
        let full_path = self.nucleo_root.join(prompt_path);
        hash_writer::write_prompt_meta(&full_path, code_hash)
    }
}

impl TransactionalHashRewriter for L3HashRewriter {
    fn preflight(&self, pair: &BijectivePair) -> Result<PairSnapshot, String> {
        hash_writer::snapshot_pair(&pair.source_path, &self.nucleo_root.join(&pair.prompt_path))
    }

    fn apply_pair(&self, pair: &BijectivePair) -> Result<(), String> {
        let original = self.preflight(pair)?;
        let result = hash_writer::write_pair(
            &pair.source_path,
            &self.nucleo_root.join(&pair.prompt_path),
            &PairSnapshot {
                source_bytes: pair.new_source_bytes.clone(),
                prompt_bytes: pair.new_prompt_bytes.clone(),
            },
        );
        if let Err(reason) = result {
            self.rollback_pair(pair, &original).map_err(|rollback| {
                format!("apply failed ({reason}); rollback failed ({rollback})")
            })?;
            return Err(reason);
        }
        Ok(())
    }

    fn rollback_pair(&self, pair: &BijectivePair, snapshot: &PairSnapshot) -> Result<(), String> {
        hash_writer::write_pair(
            &pair.source_path,
            &self.nucleo_root.join(&pair.prompt_path),
            snapshot,
        )
    }

    fn validate_pair(&self, pair: &BijectivePair) -> Result<(), String> {
        let actual = self.preflight(pair)?;
        if actual.source_bytes == pair.new_source_bytes
            && actual.prompt_bytes == pair.new_prompt_bytes
        {
            Ok(())
        } else {
            Err("paridade bidirecional ausente".into())
        }
    }
}

// ── L4 adapter: SnapshotRewriter (L3 snapshot_writer → L2 port) ──────────────

struct L3SnapshotWriter {
    nucleo_root: PathBuf,
}

impl SnapshotRewriter for L3SnapshotWriter {
    fn serialize_snapshot(&self, interface: &PublicInterface<'_>) -> String {
        FsPromptSnapshotReader {
            nucleo_root: self.nucleo_root.clone(),
        }
        .serialize_snapshot(interface)
    }

    fn write_snapshot(&self, prompt_path: &str, snapshot: &str) -> Result<(), String> {
        let full_path = self.nucleo_root.join(prompt_path);
        snapshot_writer::write_snapshot(&full_path, snapshot)
    }
}

// ── Pipeline ──────────────────────────────────────────────────────────────────

/// Parses all source files and runs per-file checks via rayon Map-Reduce.
///
/// **Fase Map** (`par_iter`):
/// - `source_errors` → V0 Fatal + `LocalIndex::from_source_error()`
/// - `source_files`  → `parser.parse()` → `run_checks()` + `LocalIndex::from_parsed()`
/// - Cada thread produz `(Vec<Violation>, Option<ParsedFile>, LocalIndex)` independentemente
///
/// **Fase Reduce** (`fold` + `reduce`):
/// - `fold`: acumula por thread sem estado compartilhado
/// - `reduce`: funde os acumuladores de cada thread
/// - `ProjectIndex::merge` é associativa e comutativa — ordem de fusão não afeta resultado
///
/// `source_files` must outlive the returned vecs — `ParsedFile<'a>` borrows from
/// them (zero-copy, ADR-0004). `P` é `Sync` — sem campo mutable compartilhado.
fn run_pipeline<'a, P: LanguageParser + Sync>(
    source_files: &'a [SourceFile],
    source_errors: &'a [SourceError],
    parser: &P,
    checks: CheckContext<'_>,
) -> (
    Vec<Violation<'a>>,
    Vec<ParsedFile<'a>>,
    ProjectIndex<'a>,
    ParseCounts,
) {
    // Fase Map ─────────────────────────────────────────────────────────────────

    // V0: unreadable files — Fatal, never silenced
    let error_map = source_errors.par_iter().map(
        |err| -> (
            Vec<Violation<'a>>,
            Option<ParsedFile<'a>>,
            LocalIndex<'a>,
            ParseCounts,
        ) {
            (
                vec![source_error_to_violation(err)],
                None,
                LocalIndex::from_source_error(),
                ParseCounts::default(),
            )
        },
    );

    // V1–V20 per file
    let file_map = source_files.par_iter().map(
        |source_file| -> (
            Vec<Violation<'a>>,
            Option<ParsedFile<'a>>,
            LocalIndex<'a>,
            ParseCounts,
        ) {
            match parser.parse(source_file) {
                Ok(parsed) => {
                    let violations = run_checks(&parsed, checks);
                    let local = LocalIndex::from_parsed(&parsed);
                    (violations, Some(parsed), local, ParseCounts::default())
                }
                Err(err) => {
                    let counts = ParseCounts::from_error(&err);
                    (
                        vec![parse_error_to_violation(err)],
                        None,
                        LocalIndex::from_parse_error(),
                        counts,
                    )
                }
            }
        },
    );

    // Fase Reduce ──────────────────────────────────────────────────────────────
    //
    // fold()   — acumula por thread; cada thread começa com acumulador vazio
    // reduce() — funde os acumuladores de threads distintas
    // ProjectIndex::merge() associativa e comutativa — ordem irrelevante

    error_map
        .chain(file_map)
        .fold(
            || {
                (
                    Vec::<Violation<'a>>::new(),
                    Vec::<ParsedFile<'a>>::new(),
                    ProjectIndex::<'a>::new(),
                    ParseCounts::default(),
                )
            },
            |(mut viols, mut parsed_acc, mut idx, counts), (v, pf, local, local_counts)| {
                viols.extend(v);
                if let Some(p) = pf {
                    parsed_acc.push(p);
                }
                idx.merge_local(local);
                (viols, parsed_acc, idx, counts.merge(local_counts))
            },
        )
        .reduce(
            || {
                (
                    Vec::new(),
                    Vec::new(),
                    ProjectIndex::new(),
                    ParseCounts::default(),
                )
            },
            |(mut viols_a, mut parsed_a, idx_a, counts_a), (viols_b, parsed_b, idx_b, counts_b)| {
                viols_a.extend(viols_b);
                parsed_a.extend(parsed_b);
                (
                    viols_a,
                    parsed_a,
                    idx_a.merge(idx_b),
                    counts_a.merge(counts_b),
                )
            },
        )
}

fn prompt_ownerships(files: &[ParsedFile<'_>]) -> Vec<PromptOwnership> {
    files
        .iter()
        .map(|file| PromptOwnership {
            code_path: file.path.to_path_buf(),
            layer: match file.layer {
                crystalline_lint::entities::layer::Layer::L0 => PromptOwnershipLayer::L0,
                crystalline_lint::entities::layer::Layer::L1 => PromptOwnershipLayer::L1,
                crystalline_lint::entities::layer::Layer::L2 => PromptOwnershipLayer::L2,
                crystalline_lint::entities::layer::Layer::L3 => PromptOwnershipLayer::L3,
                crystalline_lint::entities::layer::Layer::L4 => PromptOwnershipLayer::L4,
                crystalline_lint::entities::layer::Layer::Lab => PromptOwnershipLayer::Lab,
                crystalline_lint::entities::layer::Layer::Unknown => PromptOwnershipLayer::Unknown,
            },
            // A regra local já consome `prompt_refs`; a visão integral transporta
            // somente a referência canônica para não duplicar o mesmo V15.
            prompt_refs: file
                .prompt_header
                .as_ref()
                .map(|header| vec![header.prompt_path.to_owned()])
                .unwrap_or_default(),
        })
        .collect()
}

// ── Rule dispatcher ───────────────────────────────────────────────────────────

fn run_checks<'a>(file: &ParsedFile<'a>, checks: CheckContext<'_>) -> Vec<Violation<'a>> {
    let CheckContext {
        enabled,
        l1_ports,
        wiring_config,
        l1_allowed,
        strict_dirs,
        check_test_imports,
        wildcard_exceptions,
        v21_config,
        semantic_levels,
        citation_freshness,
    } = checks;
    let mut violations = Vec::new();
    if let Some(violation) = prompt_access_violation(file) {
        violations.push(violation);
    }
    let l1_allowed_lang = l1_allowed.for_language(&file.language);
    if enabled.v1 {
        violations.extend(prompt_header::check(file, strict_dirs));
    }
    if enabled.v2 {
        violations.extend(test_file::check(file));
    }
    if enabled.v3 {
        violations.extend(forbidden_import::check(file, check_test_imports));
    }
    if enabled.v4 {
        violations.extend(impure_core::check(file));
    }
    if enabled.v5 {
        violations.extend(prompt_drift::check(file));
    }
    if enabled.v6 {
        violations.extend(prompt_stale::check(file));
    }
    if enabled.v9 {
        violations.extend(pub_leak::check(file, l1_ports, check_test_imports));
    }
    if enabled.v10 {
        violations.extend(quarantine_leak::check(file));
    }
    if enabled.v12 {
        violations.extend(wiring_logic_leak::check(file, wiring_config));
    }
    if enabled.v13 {
        violations.extend(mutable_state_core::check(file));
    }
    if enabled.v14 {
        violations.extend(external_type_in_contract::check(
            file,
            l1_allowed_lang,
            check_test_imports,
        ));
    }
    if enabled.v15 {
        violations.extend(multi_prompt_header::check(file));
    }
    if enabled.v16 {
        violations.extend(wildcard_saturation::check(file, wildcard_exceptions));
    }
    if enabled.v17 {
        violations.extend(compound_guard::check(file));
    }
    if enabled.v18 {
        violations.extend(range_pattern::check(file));
    }
    if enabled.v19 {
        violations.extend(or_pattern_alternatives::check(file));
    }
    if enabled.v20 {
        violations.extend(deep_pattern_nesting::check(file));
    }
    if enabled.v27 {
        violations.extend(mergeable_decision_arms::check(file));
    }
    if enabled.v21 {
        violations.extend(unsourced_constant::check(
            file,
            v21_config,
            citation_freshness,
        ));
    }
    if enabled.v23 {
        violations.extend(context_erasure::check(file, semantic_levels[0].clone()));
    }
    if enabled.v24 {
        violations.extend(semantic_field_loss::check(file, semantic_levels[1].clone()));
    }
    if enabled.v25 {
        violations.extend(decision_ownership::check(file, semantic_levels[2].clone()));
    }
    violations
}
