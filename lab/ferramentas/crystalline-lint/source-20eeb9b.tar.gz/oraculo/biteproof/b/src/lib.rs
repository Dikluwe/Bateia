pub struct Thing;
