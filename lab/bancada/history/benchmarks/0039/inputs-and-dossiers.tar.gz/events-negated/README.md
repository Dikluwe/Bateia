# Event processor
Asynchronous event processing. Works offline.
This tool does not upload code.
