//! Crystalline Lineage
//! @prompt 00_nucleo/prompts/contracts/language-parser.md
//! @prompt-hash 7d8e000a
//! @layer L1
//! @updated 2026-03-13

use crate::contracts::file_provider::SourceFile;
use crate::contracts::parse_error::ParseError;
use crate::entities::layer::Language;
use crate::entities::parsed_file::ParsedFile;

/// Boundary between L3 (tree-sitter grammar) and L1 (rules).
/// L3 implements, L1 consumes.
/// Receives a reference to SourceFile so ParsedFile<'a> can borrow
/// from the source buffer — zero-copy per ADR-0004.
pub trait LanguageParser {
    fn parse<'a>(&self, file: &'a SourceFile) -> Result<ParsedFile<'a>, ParseError>;
}

/// Pure L1 decision identifying which language port must receive a source file.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ParserSlot {
    Rust,
    TypeScript,
    Python,
    C,
    Cpp,
    Zig,
    Go,
    Java,
    Elixir,
}

/// Maps the closed domain language enum to its parser port without consulting L3.
pub fn parser_slot(language: &Language) -> Option<ParserSlot> {
    match language {
        Language::Rust => Some(ParserSlot::Rust),
        Language::TypeScript => Some(ParserSlot::TypeScript),
        Language::Python => Some(ParserSlot::Python),
        Language::C => Some(ParserSlot::C),
        Language::Cpp => Some(ParserSlot::Cpp),
        Language::Zig => Some(ParserSlot::Zig),
        Language::Go => Some(ParserSlot::Go),
        Language::Java => Some(ParserSlot::Java),
        Language::Elixir => Some(ParserSlot::Elixir),
        Language::Unknown => None,
    }
}

/// Total set of language ports assembled by L4 from concrete L3 adapters.
pub struct ParserSet<'p> {
    pub rust: &'p dyn LanguageParser,
    pub typescript: &'p dyn LanguageParser,
    pub python: &'p dyn LanguageParser,
    pub c: &'p dyn LanguageParser,
    pub cpp: &'p dyn LanguageParser,
    pub zig: &'p dyn LanguageParser,
    pub go: &'p dyn LanguageParser,
    pub java: &'p dyn LanguageParser,
    pub elixir: &'p dyn LanguageParser,
}

impl ParserSet<'_> {
    /// Routes once to the selected port and propagates its result unchanged.
    pub fn parse<'a>(&self, file: &'a SourceFile) -> Result<ParsedFile<'a>, ParseError> {
        let parser = match parser_slot(&file.language) {
            Some(ParserSlot::Rust) => self.rust,
            Some(ParserSlot::TypeScript) => self.typescript,
            Some(ParserSlot::Python) => self.python,
            Some(ParserSlot::C) => self.c,
            Some(ParserSlot::Cpp) => self.cpp,
            Some(ParserSlot::Zig) => self.zig,
            Some(ParserSlot::Go) => self.go,
            Some(ParserSlot::Java) => self.java,
            Some(ParserSlot::Elixir) => self.elixir,
            None => {
                return Err(ParseError::UnsupportedLanguage {
                    path: file.path.clone(),
                    language: file.language.clone(),
                });
            }
        };

        parser.parse(file)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::entities::layer::{Language, Layer};
    use crate::entities::parsed_file::ParsedFile;
    use std::path::{Path, PathBuf};

    struct MockParser {
        result: Result<ParsedFile<'static>, ParseError>,
    }

    impl LanguageParser for MockParser {
        fn parse<'a>(&self, _file: &'a SourceFile) -> Result<ParsedFile<'a>, ParseError> {
            self.result.clone()
        }
    }

    fn valid_parsed_file() -> ParsedFile<'static> {
        ParsedFile {
            path: Path::new("01_core/foo.rs"),
            layer: Layer::L1,
            language: Language::Rust,
            source_role: crate::contracts::file_provider::SourceRole::Production,
            prompt_header: None,
            prompt_presence: crate::contracts::prompt_reader::PromptPresence::Missing,
            prompt_refs: vec![],
            has_test_coverage: false,
            imports: vec![],
            tokens: vec![],
            public_interface: crate::entities::parsed_file::PublicInterface::empty(),
            prompt_snapshot: None,
            declared_traits: vec![],
            implemented_traits: vec![],
            blanket_impl_traits: vec![],
            declarations: vec![],
            static_declarations: vec![],
            module_decls: vec![],
            decision_exprs: vec![],
            constants: vec![],
            semantic_observations: vec![],
        }
    }

    fn make_source_file(path: &str) -> SourceFile {
        SourceFile {
            path: PathBuf::from(path),
            content: "fn main() {}".to_string(),
            language: Language::Rust,
            layer: Layer::L1,
            source_role: crate::contracts::file_provider::SourceRole::Production,
            has_adjacent_test: false,
        }
    }

    #[test]
    fn mock_parser_returns_ok_for_valid_source() {
        let parser = MockParser {
            result: Ok(valid_parsed_file()),
        };
        let file = make_source_file("01_core/foo.rs");
        let result = parser.parse(&file);
        assert!(result.is_ok());
    }

    #[test]
    fn mock_parser_returns_err_for_invalid_source() {
        let parser = MockParser {
            result: Err(ParseError::SyntaxError {
                path: PathBuf::from("01_core/bad.rs"),
                line: 3,
                column: 5,
                message: "unexpected token".to_string(),
            }),
        };
        let file = make_source_file("01_core/bad.rs");
        let result = parser.parse(&file);
        assert!(result.is_err());
    }
}
