# Prompt: Contract - File Provider (file-provider)
Hash do Código: ee00e97d

**Camada**: L1 (Core — Contracts)
**Criado em**: 2025-03-13
**Revisado em**: 2026-03-15 (ADR-0006: SourceError.path() accessor)
**Arquivos gerados**:
  - 01_core/contracts/file_provider.rs

---

## Contexto

Este contrato define como L1 espera receber arquivos de código do
mundo exterior. L1 não sabe o que é um disco rígido nem se importa
com `walkdir`.

`SourceFile` é o **dono** (`owner`) do conteúdo carregado em memória.
`ParsedFile<'a>` e `Violation<'a>` referenciam fatias desse conteúdo
via lifetime `'a` — nunca copiam. A ordem de destruição é garantida
pelo compilador: `SourceFile` deve viver mais que qualquer estrutura
que o referencia.

**Diretiva Fail-Fast (ADR-0004):** Um linter que silencia erros de
I/O gera falsos negativos — `exit 0` pode apenas significar que
metade dos arquivos era ilegível. O contrato proíbe essa supressão:
erros de leitura são propagados como `SourceError` e convertidos
em violações `V0 Fatal` pelo wiring em L4.

---

## Estruturas de Dados

### `SourceFile`
```rust
/// Dono (owner) do conteúdo do arquivo em memória.
/// ParsedFile<'a> e Violation<'a> pegam fatias emprestadas daqui.
/// Destruir SourceFile invalida todos os ParsedFile derivados dele.
#[derive(Debug)]
pub struct SourceFile {
    pub path: PathBuf,
    pub content: String,
    pub language: Language,
    /// Resolvido pelo walker via crystalline.toml
    pub layer: Layer,
    /// Papel estrutural derivado do path/linguagem, nunca do conteúdo
    pub source_role: SourceRole,
    /// true se foo_test.rs existe no mesmo diretório que foo.rs
    /// Verificado pelo walker no momento da descoberta
    pub has_adjacent_test: bool,
}
```

`SourceRole` é fechado em `Production | Test | Unknown`. O walker é a única autoridade de
classificação; parsers apenas transportam o valor. `Unknown` preserva fontes aceitas cujo
nome não pode ser classificado deterministicamente e deve originar `SourceError::Unreadable`/V0 antes
do parse. Um arquivo `Test` não é considerado produção coberta e não precisa possuir outro
teste.

### `SourceError` (ADR-0004)
```rust
/// Falha crítica ao tentar carregar um arquivo.
/// Convertida em Violation { rule_id: "V0", level: Fatal } pelo projetor puro L1;
/// o wiring apenas encaminha o erro.
/// Não pode ser suprimida — ausência de V0 garante que todos os
/// arquivos foram lidos com sucesso.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum SourceError {
    Unreadable {
        path: PathBuf,
        reason: String,
    },
}

impl SourceError {
    /// Accessor para o path do arquivo que falhou.
    /// Usado pelo pipeline e pelo projetor puro com Cow::Owned(path).
    pub fn path(&self) -> &Path {
        match self {
            SourceError::Unreadable { path, .. } => path,
        }
    }
}
```

---

## Contrato (Trait)
```rust
pub trait FileProvider {
    /// Retorna iterador de arquivos lidos com sucesso ou erros de acesso.
    /// L4 usa par_bridge() para paralelizar — o iterador deve ser
    /// Send se a implementação suportar paralelismo.
    /// Nunca retorna Ok() para arquivo parcialmente lido.
    fn files(&self) -> impl Iterator<Item = Result<SourceFile, SourceError>>;
}
```

## Partição pura de resultados

A separação do stream produzido por L3 é transformação pura L1, pública para gate
black-box:

```rust
pub fn collect_walker_results<I>(
    results: I,
) -> (Vec<SourceFile>, Vec<SourceError>)
where
    I: Iterator<Item = Result<SourceFile, SourceError>>;
```

A função toma o iterador por valor, não exige `Clone`, começa com dois `Vec::new()` e
move cada item por `push`, sem reconstruir ou normalizar campos. Cada saída é exatamente
a subsequência estável de seu ramo, preservando duplicatas e multiplicidade.

O consumo chama `next()` uma vez por item e uma vez adicional para observar o primeiro
`None`; nunca chama novamente após esse `None`, não faz replay/segunda coleta e não chama
`size_hint`. Nenhum filesystem, config, ambiente, relógio, rede ou processo é acessado.
L3 produz os resultados; L4 somente chama esta função L1.

---

## Restrições

- `FileProvider` nunca silencia arquivos ilegíveis — propaga `SourceError`
- Ignora intencionalmente apenas diretórios em `config.excluded` —
  não arquivos individuais
- `SourceFile` não implementa `Clone` intencionalmente — o conteúdo
  é grande e deve ser carregado uma única vez por arquivo
- L1 nunca instancia `SourceFile` diretamente — responsabilidade
  exclusiva de L3

---

## Critérios de Verificação
```
Dado diretório com dois arquivos .rs legíveis
Quando files() for chamado
Então retorna iterator com dois Ok(SourceFile)

Dado arquivo com permissão de leitura negada
Quando files() for chamado
Então retorna Err(SourceError::Unreadable) para esse arquivo
E continua iterando os demais — não aborta o iterator

Dado SourceError::Unreadable { path, .. }
Quando path() for chamado
Então retorna &Path do arquivo que falhou

Dado diretório com target/ em config.excluded
Quando files() for chamado
Então nenhum arquivo de target/ aparece no iterator

Dado SourceFile com path em 01_core/
Quando layer for acessado
Então layer = Layer::L1

Dado SourceFile para foo.rs com foo_test.rs adjacente
Quando has_adjacent_test for acessado
Então retorna true

Dado mock de FileProvider retornando SourceFiles fixos
Quando usado em teste de L1
Então nenhum acesso a disco ocorre

Dado iterador instrumentado alternando Ok/Err e duplicatas
Quando collect_walker_results for chamado
Então preserva as duas subsequências estáveis e toda multiplicidade
E chama next exatamente itens+1 vezes, size_hint zero vezes e nunca após EOF

Dado FileProvider com um Ok e um Err
Quando L4 processar o iterator
Então Ok → ParsedFile → regras
E Err → Violation { rule_id: "V0", level: Fatal }
```

---

## Histórico de Revisões

| Data | Motivo | Arquivos afetados |
|------|--------|-------------------|
| 2025-03-13 | Criação inicial | file_provider.rs |
| 2025-03-13 | Gap 4: layer e has_adjacent_test, tabela de responsabilidades | file_provider.rs |
| 2026-03-14 | ADR-0004: SourceError adicionado, files() retorna Result, SourceFile não-Clone | file_provider.rs |
| 2026-03-15 | ADR-0006: SourceError.path() accessor adicionado — necessário para LocalIndex::from_alien() e source_error_to_violation() em L4 | file_provider.rs |
