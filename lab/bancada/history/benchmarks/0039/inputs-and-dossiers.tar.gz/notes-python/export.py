def export_notes(notes):
    return "\n\n".join("# " + title + "\n" + body for title, body in notes)
