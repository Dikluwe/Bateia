# Event processor
Asynchronous event processing. Works offline.
