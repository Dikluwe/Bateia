# Alternativas para Evitar iniciar software do zero quando projetos, componentes ou padrões reutilizáveis já resolvem toda ou parte da ideia, produzindo uma decisão de partida baseada em evidências.

Fonte canônica: [alternatives.json](alternatives.json)

## Alternativas

| Repositório | Fit | Cobertura | Estrelas | Licença |
|---|---:|---:|---:|---|

## Excluídos

| Repositório | Fit | Razões e bloqueios |
|---|---:|---|
| `local/bateia-a061b61e@a70fccdd71bafbd82985741068cf4d5ad296b31568f2b5760700a6fcd454cd6a` | INCONCLUSIVE | alinhamento do problema inconclusivo; cobertura comprovada: 0/10; licença não reconhecida; valide os termos antes da adoção; manutenção inconclusiva; operação local inconclusiva |
