# Alternativas para asynchronous event processing

Fonte canônica: [alternatives.json](alternatives.json)

## Alternativas

| Repositório | Fit | Cobertura | Estrelas | Licença |
|---|---:|---:|---:|---|

## Excluídos

| Repositório | Fit | Razões e bloqueios |
|---|---:|---|
| `local/events-go-177e390c@ab96b4315f5f4caf4efa8e7bb1a1e39116a1b15c78d540b1645600f6e6b908d4` | INCONCLUSIVE | cobertura comprovada: 0/1; manutenção inconclusiva |
| `local/notes-python-44c8b132@86486f36639b17c652fd4403d8e62b54c81cad780fe0585ecf932cef10692036` | INCONCLUSIVE | cobertura comprovada: 0/1; manutenção inconclusiva |
