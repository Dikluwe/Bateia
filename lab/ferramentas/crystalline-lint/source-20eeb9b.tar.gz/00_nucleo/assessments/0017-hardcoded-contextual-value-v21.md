# Assessment 0017 — HardcodedContextualValue V21

**Estado:** READY WITH RESIDUAL AUDIT
**Data:** 2026-08-24
**Passo:** P0088
**Baseline:** `ccca54941e4c2043f1e4557abcd09c08697a3a8b`
**Alvos previstos:** classificador V21 L1 e seam/adapter de frescura L3

## Insumos normativos autorizados

| Unidade | Caminho | SHA-256 |
|---|---|---|
| V21 | `00_nucleo/prompts/unsourced-constant.md` | `6fe0f1ed9b59b206be628b292bc507f8eb50227d2ececb01236181b4bc7dba91` |
| IR | `00_nucleo/prompts/contracts/rule-traits.md` | `cdba18365badfb56288480f683451914d88b0df07201acc43ee8334d22289ba3` |
| porta de frescura | `00_nucleo/prompts/contracts/citation-freshness.md` | `459a7c29e8ad2f842ba4ef2d6cece4d50b5fd76a6da72067f212d99f8c155402` |
| arquitetura/wiring | `00_nucleo/prompts/linter-core.md` | `ed44ffdda0a323df26a25cef40c0acb46bd692db6fdaef861a20a509adeb7029` |
| diagnóstico | `00_nucleo/prompts/violation-types.md` | `b50d90505e311a1aa99d3c80988f3f7996fe7974d71579543f86c0553a4dc314` |
| distinção V16/V21 | `00_nucleo/adr/0017-v16-v21-diferenca-categorica.md` | `79f406654aacf3693616232a4fdbb911e359486d089ffde841af5375625104dd` |
| protocolo | `00_nucleo/tekt-linter-passo-0088-triagem-v21.md` | `9bd09fd5566805e7bc9cb012b49d7cbefadb961e8f7704b88ea1ec2fe8b2e9e6` |

## Natureza e bloqueio inicial

Assessment retroativo. O L0 agora fecha o anti-apodrecimento de `// ref:` por porta
causal explícita e política executável `valid/stale/unknown`, preservando a proibição de
filesystem em L1. O I/O direto observado no classificador permanece `RED` arquitetural;
produção só pode mudar depois de gates cegos congelados contra estes hashes.

## Alegações L1 a congelar

1. V21 é silenciosa fora de Rust e em coleção vazia.
2. O predicado exige simultaneamente scaling binário, fonte contextual e sumidouro
   geométrico; ausência de qualquer eixo é silenciosa.
3. Format modules, test-origin, data-table e literais triviais são isentos exatamente
   segundo configuração/L0; paths e nomes parecidos não ganham isenção acidental.
4. Sem citação, ocorrência elegível gera V21 Warning ou Error em strict module.
5. `Spec` e `Rationale` válidas silenciam; `Ref` só silencia sob frescura `valid`.
6. `stale` gera diagnóstico explícito; `unknown` nunca vira válido nem silêncio.
7. Mensagem preserva literal, context var, sink e modalidade relevante; location vem da
   constante. Ordem e multiplicidade de ocorrências são preservadas.
8. Configuração e campos irrelevantes não causam inferência adicional; V21 nunca emite
   V22 nem acessa filesystem, rede, relógio, ambiente ou processo.

## Alegações da porta/adapter L3

1. A porta expõe estado fechado `valid | stale | unknown`, sem bool que confunda erro
   externo com validade.
2. Arquivo e linha existentes/não vazios são `valid`; path ausente, linha zero, além de
   EOF ou linha vazia são `stale`.
3. Entrada fora da raiz, symlink escape, erro de leitura, orçamento/encoding não
   suportado são bloqueados como `unknown` ou erro explícito conforme L0 saneado.
4. Resolução é read-only, confinada, determinística, sem rede, hooks ou escrita.
5. L3 implementa a porta; não duplica listas, predicado contextual, severidade ou
   formatação de diagnóstico V21.

## Gates segregados

- **B1 L1:** matriz de languages; produto dos três eixos; filtros/configuração; triviais;
  citações e três estados; strict; evidência; ordem/multiplicidade; mock puro sem I/O.
- **B2 L3:** filesystem temporário; linhas válida/vazia/ausente/extrema; confinamento,
  symlink, Unicode, orçamento e imutabilidade; sem importar classificador como oráculo.
- **C:** confronto somente após gates congelados.
- **D:** adversário final verifica causalidade L0→porta/L1/L3, gravidade, gates,
  regressão V22 e ausência de delta escondido em parser/config/CLI.

Resultados possíveis: `PASS`, `RED`, `SPEC-GAP`, `GATE-DEFECT`. O lote fecha somente com
`READY WITH RESIDUAL AUDIT` ou `BLOCKED`, relatório P0088 e nenhum merge.

## Fechamento

- B1 L1: 9/9 PASS.
- B2 L3: 9/9 PASS, incluindo troca concorrente por symlink e remoção/recriação.
- RED de I/O em L1 e RED-D1 TOCTOU: fechados causalmente.
- GATE-DEFECT-D1/D2: fechados antes do veredito final.
- Suíte workspace, 83 fixtures e regressão V22: PASS.
- Veredito adversarial final: `READY WITH RESIDUAL AUDIT`.
