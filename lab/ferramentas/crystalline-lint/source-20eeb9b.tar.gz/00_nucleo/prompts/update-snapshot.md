# Prompt: planejamento de update-snapshot
Hash do Código: daea64cc

Owner exclusivo: `02_shell/update_snapshot.rs`.

Planejar atualização da seção gerada de snapshot para pares owner únicos, sem tocar texto
humano. Conflitos, ausência e paths hostis bloqueiam o lote inteiro.

## Critério observável

Gates distinguem missing/unreadable/ready, preservam ordem e provam que dry-run não chama
writer; somente a seção gerada é elegível.
