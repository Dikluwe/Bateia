# Alternativas para Exportar notas para Markdown

Fonte canônica: [alternatives.json](alternatives.json)

## Alternativas

| Repositório | Fit | Cobertura | Estrelas | Licença |
|---|---:|---:|---:|---|

## Excluídos

| Repositório | Fit | Razões e bloqueios |
|---|---:|---|
| `local/notes-python-44c8b132@86486f36639b17c652fd4403d8e62b54c81cad780fe0585ecf932cef10692036` | INCONCLUSIVE | alinhamento do problema inconclusivo; cobertura comprovada: 0/1; manutenção inconclusiva |
