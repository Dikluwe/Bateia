package events
import "testing"
func TestEventProcessor(t *testing.T) { if EventProcessor("x") != "x" {t.Fatal("echo failed")} }
