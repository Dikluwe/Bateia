from export import export_notes
def test_export():
    assert export_notes([("Title", "Body")]) == "# Title\nBody"
