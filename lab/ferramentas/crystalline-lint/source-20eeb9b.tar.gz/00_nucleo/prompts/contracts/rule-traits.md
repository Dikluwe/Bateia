# Prompt: Rule Traits (rule-traits)
Hash do Código: e4fdf304

**Camada**: L1 (Core — Contracts)
**Criado em**: 2026-03-15 (ADR-0006 refactor)
**Revisado em**: 2026-03-18 (ADR-0009 correcção: HasTokens ganha language() para V4 multi-linguagem)
**Arquivos gerados**:
  - 01_core/entities/rule_traits.rs

---

## Contexto

Cada regra V1–V12 precisa de um subconjunto específico dos campos
de `ParsedFile<'a>` para operar. O Claude Code implementou esse
acesso via traits locais em cada arquivo de regra, com
`ParsedFile` implementando todas em `parsed_file.rs`.

O problema: `parsed_file.rs` pertence a `entities/` e passou a
importar de `rules/` — inversão de dependência dentro de L1.
Entities não deve conhecer rules.

A correção move todas as traits de acesso para `entities/` —
o lugar correcto para contratos que definem como entidades expõem
os seus dados. `parsed_file.rs` implementa de `entities/rule_traits`,
cada regra importa de `entities/rule_traits`. A direção é correcta:
```
rules/ → entities/rule_traits → entities/parsed_file    ✅ correcto
entities/parsed_file → rules/                           ❌ inversão
```

**Nota sobre localização:** Este ficheiro vive em
`01_core/entities/rule_traits.rs` desde o ADR-0007, que moveu
as traits de acesso de `contracts/` para `entities/`. `contracts/`
contém exclusivamente portas de infraestrutura — traits cujo
`impl` pertence a L2 ou L3.

---

## Traits

```rust
use std::path::Path;
use crate::entities::layer::{Language, Layer};
use crate::entities::parsed_file::{
    Declaration, Import, PromptHeader, PublicInterface, Token,
};

/// Para V1 — verifica presença e validade do @prompt header
pub trait HasPromptFilesystem<'a> {
    fn layer(&self) -> &Layer;
    fn prompt_header(&self) -> Option<&PromptHeader<'a>>;
    fn prompt_file_exists(&self) -> bool;
    fn path(&self) -> &'a Path;
}

/// Para V2 — verifica cobertura de testes em L1
pub trait HasCoverage<'a> {
    fn layer(&self) -> &Layer;
    fn source_role(&self) -> SourceRole;
    fn has_test_coverage(&self) -> bool;
    fn path(&self) -> &'a Path;
}

/// Para V3, V9 e V10 — verifica imports por camada e subdiretório
///
/// V3 usa target_layer para detectar inversão de dependência.
/// V9 usa target_subdir para detectar imports fora das portas de L1.
/// V10 usa target_layer == Layer::Lab para detectar quarantine leak.
/// Nenhuma das três usa ImportKind — ImportKind descreve mecânica
/// estrutural, não linguagem. As regras são agnósticas de linguagem.
pub trait HasImports<'a> {
    fn layer(&self) -> &Layer;
    fn imports(&self) -> &[Import<'a>];
    fn path(&self) -> &'a Path;
}

/// Para V4 — verifica tokens de I/O em L1
///
/// language() é necessário para que V4 seleccione a lista de símbolos
/// proibidos correspondente à linguagem do arquivo.
/// V4 nunca usa ImportKind para distinguir linguagens — usa language().
pub trait HasTokens<'a> {
    fn layer(&self) -> &Layer;
    fn language(&self) -> &Language;
    fn tokens(&self) -> &[Token<'a>];
    fn path(&self) -> &'a Path;
}

/// Para V5 — verifica drift de hash entre prompt e código
pub trait HasHashes<'a> {
    fn prompt_header(&self) -> Option<&PromptHeader<'a>>;
    fn path(&self) -> &'a Path;
}

/// Para V6 — verifica drift de interface pública
pub trait HasPublicInterface<'a> {
    fn prompt_header(&self) -> Option<&PromptHeader<'a>>;
    fn public_interface(&self) -> &PublicInterface<'a>;
    fn prompt_snapshot(&self) -> Option<&PublicInterface<'a>>;
    fn path(&self) -> &'a Path;
}

/// Para V9 — verifica imports de subdiretórios não-porta de L1
pub trait HasPubLeak<'a> {
    fn layer(&self) -> &Layer;
    fn imports(&self) -> &[Import<'a>];
    fn path(&self) -> &'a Path;
}

/// Para V12 — verifica declarações de tipo em L4
///
/// `declarations()` expõe struct/enum/impl-sem-trait/class/interface/
/// type-alias de nível superior.
/// V12 filtra por `layer() == Layer::L4` internamente.
/// `impl Trait for Type` e `class implements` não aparecem em
/// `declarations()` — são adapters permitidos em L4.
pub trait HasWiringPurity<'a> {
    fn layer(&self) -> &Layer;
    fn declarations(&self) -> &[Declaration<'a>];
    fn path(&self) -> &'a Path;
}
```

**Nota sobre V3, V9 e V10:** as três regras consomem `HasImports`.
V3 verifica `target_layer`, V9 verifica `target_subdir`, V10
verifica `target_layer == Layer::Lab`. A trait é a mesma — as
regras diferem no predicado de filtragem.

**Nota sobre V4 e `language()`:** `HasTokens` expõe `language()`
para que V4 possa seleccionar a lista de símbolos proibidos
correspondente sem conhecer a sintaxe de nenhuma linguagem.
`forbidden_symbols_for(language)` vive em `impure_core.rs` —
não na IR.

---

## Implementações em `parsed_file.rs`

`ParsedFile<'a>` implementa todas as traits acima.
As implementações vivem em `parsed_file.rs` — não num arquivo
separado — porque são triviais (um campo por método).

```rust
// Em 01_core/entities/parsed_file.rs
use crate::entities::rule_traits::{
    HasPromptFilesystem, HasCoverage, HasImports,
    HasTokens, HasHashes, HasPublicInterface,
    HasPubLeak, HasWiringPurity,
};

impl<'a> HasPromptFilesystem<'a> for ParsedFile<'a> {
    fn layer(&self) -> &Layer { &self.layer }
    fn prompt_header(&self) -> Option<&PromptHeader<'a>> {
        self.prompt_header.as_ref()
    }
    fn prompt_file_exists(&self) -> bool { self.prompt_file_exists }
    fn path(&self) -> &'a Path { self.path }
}

impl<'a> HasCoverage<'a> for ParsedFile<'a> {
    fn layer(&self) -> &Layer { &self.layer }
    fn has_test_coverage(&self) -> bool { self.has_test_coverage }
    fn path(&self) -> &'a Path { self.path }
}

impl<'a> HasImports<'a> for ParsedFile<'a> {
    fn layer(&self) -> &Layer { &self.layer }
    fn imports(&self) -> &[Import<'a>] { &self.imports }
    fn path(&self) -> &'a Path { self.path }
}

impl<'a> HasTokens<'a> for ParsedFile<'a> {
    fn layer(&self) -> &Layer { &self.layer }
    fn language(&self) -> &Language { &self.language }  // novo — para V4
    fn tokens(&self) -> &[Token<'a>] { &self.tokens }
    fn path(&self) -> &'a Path { self.path }
}

impl<'a> HasHashes<'a> for ParsedFile<'a> {
    fn prompt_header(&self) -> Option<&PromptHeader<'a>> {
        self.prompt_header.as_ref()
    }
    fn path(&self) -> &'a Path { self.path }
}

impl<'a> HasPublicInterface<'a> for ParsedFile<'a> {
    fn prompt_header(&self) -> Option<&PromptHeader<'a>> {
        self.prompt_header.as_ref()
    }
    fn public_interface(&self) -> &PublicInterface<'a> { &self.public_interface }
    fn prompt_snapshot(&self) -> Option<&PublicInterface<'a>> {
        self.prompt_snapshot.as_ref()
    }
    fn path(&self) -> &'a Path { self.path }
}

impl<'a> HasPubLeak<'a> for ParsedFile<'a> {
    fn layer(&self) -> &Layer { &self.layer }
    fn imports(&self) -> &[Import<'a>] { &self.imports }
    fn path(&self) -> &'a Path { self.path }
}

impl<'a> HasWiringPurity<'a> for ParsedFile<'a> {
    fn layer(&self) -> &Layer { &self.layer }
    fn declarations(&self) -> &[Declaration<'a>] { &self.declarations }
    fn path(&self) -> &'a Path { self.path }
}
```

### IR pública de V21

```rust
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ConstantKind {
    FunctionNumberLiteral, FunctionStringLiteral, ItemDefinition,
    MatchPattern, FormatString, NegativeLiteral,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum CitationKind<'a> {
    Ref { path: &'a str, line: usize }, Spec(&'a str), Rationale(&'a str),
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Citation<'a> { pub kind: CitationKind<'a>, pub raw: &'a str, pub line: usize }

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct SourceConstant<'a> {
    pub kind: ConstantKind,
    pub snippet: &'a str,
    pub line: usize,
    pub column: usize,
    pub citation: Option<Citation<'a>>,
    pub is_test_origin: bool,
    pub function_return_type: Option<&'a str>,
    pub is_in_binary_scaling: bool,
    pub context_var: Option<String>,
    pub geometric_sink: Option<String>,
    pub is_in_data_table: bool,
}

pub trait HasConstants<'a> {
    fn layer(&self) -> &Layer;
    fn constants(&self) -> &[SourceConstant<'a>];
    fn path(&self) -> &'a Path;
    fn language(&self) -> &Language;
}
```

---

## Impacto em cada arquivo de regra

V1 usa `HasPromptFilesystem.layer()` para restringir seu escopo a L1–L4 sem
inferir camada pelo path. V4 usa `HasTokens.language()` para selecionar a lista:

```rust
// Em rules/impure_core.rs — usa language() para seleccionar lista
pub fn check<'a, T: HasTokens<'a>>(file: &T) -> Vec<Violation<'a>> {
    if *file.layer() != Layer::L1 { return vec![]; }
    let forbidden = forbidden_symbols_for(file.language());  // novo
    file.tokens()
        .iter()
        .filter(|t| is_forbidden_symbol(&t.symbol, forbidden))
        .map(|t| make_violation(file, t))
        .collect()
}
```

Mocks de teste de V4 precisam de implementar `language()`:
```rust
// Antes — mock sem language()
struct MockFile { layer: Layer, tokens: Vec<Token<'static>>, path: &'static Path }

// Depois — mock com language()
struct MockFile {
    layer: Layer,
    language: Language,  // novo campo
    tokens: Vec<Token<'static>>,
    path: &'static Path,
}
impl HasTokens<'static> for MockFile {
    fn layer(&self) -> &Layer { &self.layer }
    fn language(&self) -> &Language { &self.language }  // novo
    fn tokens(&self) -> &[Token<'static>] { &self.tokens }
    fn path(&self) -> &'static Path { self.path }
}
```

## Contagem sintática de alternativas V19

`DecisionArm.or_alternatives` é a soma das alternativas escritas em cada grupo
de or-patterns, saturada em `u16::MAX`; sem grupo, preserva o sentinela histórico 1.
Uma cadeia `A | B | C` é um grupo com 3 alternativas, independentemente da
associatividade dos nós AST. Grupos dentro de construtores ou parênteses são
contados também: `Some(A | B) | None` soma 2 alternativas externas e 2 internas.
Comentários, guard e corpo não participam da contagem.

| Padrão | Alternativas escritas nos grupos | Combinações sintáticas (não armazenadas) |
|--------|---------------------------------|-----------------------------------------|
| `(A | B, C | D)` | 4 | 4 |
| `(A | B, C | D | E)` | 5 | 6 |
| `Some(A | B) | None` | 4 | 3 |

Combinações sintáticas são expansões por soma nas escolhas e produto nas
composições; podem se sobrepor ou ser inalcançáveis. Nenhuma dessas métricas
estabelece casos efetivamente cobertos por testes, que exigem evidência de execução.

## Contrato de observações semânticas V23–V25

V23–V25 preservam a direção cristalina `rules → entities`: as regras L1 não importam
parsers, configuração ou infraestrutura. L3 resolve contratos e fluxo e materializa uma
ocorrência já classificada nesta IR pública:

```rust
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum SemanticObservationKind {
    ContextNeutralArgument,
    ContextErasingProjection,
    NeutralProjectionDestination,
    DuplicateDecisionOwner,
    DecisionProxyReentry,
    CanonicalizerReentry,
    DirectDecisionReimplementation,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct SemanticObservation {
    pub contract_id: String,
    pub kind: SemanticObservationKind,
    pub detail: String,
    pub line: usize,
    pub column: usize,
}

pub trait HasSemanticObservations<'a> {
    fn semantic_observations(&self) -> &[SemanticObservation];
    fn path(&self) -> &'a Path;
    fn language(&self) -> &Language;
}
```

`DirectDecisionReimplementation` representa a quarta modalidade V25 definida pelo
prompt `rules/decision-ownership.md`. A taxonomia é fechada: adicionar, remover ou fundir
uma variante exige primeiro revisão coordenada deste L0 e do L0 da regra consumidora.

`SemanticObservation` é ocorrência diagnóstica, não fato de conjunto. A entidade não
deduplica, ordena nem interpreta `detail`; classifiers preservam ordem e multiplicidade.
`ParsedFile` implementa `HasSemanticObservations` por empréstimo somente leitura. A
decisão que produz cada kind pertence a L3 e será auditada separadamente.

## Contrato de constantes e citações V21

V21 consome `ConstantKind`, `CitationKind`, `Citation`, `SourceConstant` e
`HasConstants`. Os campos públicos normativos são os materializados em
`01_core/entities/rule_traits.rs`: kind, snippet, line, column, citation, test-origin,
function-return-type, scaling, context-var, geometric-sink e data-table. A trait expõe
layer, constants, path e language somente leitura.

Frescura de `CitationKind::Ref` não pertence à IR nem ao parser. O classificador recebe
a porta pura `contracts/citation-freshness.md`; entities/rules não importam filesystem ou
o adapter L3.

---

## Restrições

- `rule_traits.rs` importa apenas de `entities/` — sem imports
  de `rules/` ou de `contracts/`
- As traits são somente leitura — nenhum método mutável
- `parsed_file.rs` importa de `entities::rule_traits` —
  nunca de `rules/`
- Cada regra importa apenas a trait que usa — não o módulo inteiro
- `HasTokens.language()` é o único canal pelo qual V4 conhece
  a linguagem — nunca via `ImportKind` ou condicionais na regra
- `HasWiringPurity.declarations()` retorna apenas declarações
  de nível superior — não itens aninhados em funções ou blocos
- `HasPromptFilesystem.layer()` é o único oráculo de escopo de V1; L0, Lab e
  Unknown são excluídas antes da avaliação de header e existência

---

## Critérios de Verificação

```
Dado parsed_file.rs
Quando inspecionado por imports
Então não contém nenhum import de crate::rules::*
— inversão de dependência eliminada

Dado rules/pub_leak.rs
Quando inspecionado
Então HasPubLeak não está definida localmente
E importa de crate::entities::rule_traits::HasPubLeak

Dado MockFile implementando HasPubLeak em teste de pub_leak.rs
Quando check() for chamado com MockFile
Então funciona identicamente ao ParsedFile
— testabilidade preservada

Dado rule_traits.rs
Quando inspecionado por imports
Então importa apenas de crate::entities::*
— sem imports de rules/ ou contracts/

Dado rule_traits.rs
Quando inspecionado no núcleo histórico V1–V12
Então contém as traits:
  HasPromptFilesystem, HasCoverage, HasImports, HasTokens,
  HasHashes, HasPublicInterface, HasPubLeak, HasWiringPurity
— sem traits locais remanescentes em arquivos de regra

Dado SemanticObservationKind
Quando inspecionado
Então contém exatamente as sete variantes normativas V23–V25
E DirectDecisionReimplementation é distinta de proxy e canonicalizer reentry

Dado ParsedFile
Quando usado como HasSemanticObservations
Então expõe observações por empréstimo somente leitura, path e language
E nenhuma regra L1 importa parser ou configuração L3

Dado MockFile implementando HasTokens
Com layer = L1, language = Rust
E tokens = [Token { symbol: "std::fs::read", .. }]
Quando impure_core::check() for chamado
Então retorna Violation V4
— language() exposto via HasTokens, lista Rust seleccionada

Dado MockFile implementando HasTokens
Com layer = L1, language = Python
E tokens = [Token { symbol: "os.path.join", .. }]
Quando impure_core::check() for chamado
Então retorna Violation V4
— language() exposto via HasTokens, lista Python seleccionada

Dado MockFile implementando HasTokens
Com layer = L1, language = TypeScript
E tokens = [Token { symbol: "Date.now", .. }]
Quando impure_core::check() for chamado
Então retorna Violation V4
— language() exposto via HasTokens, lista TypeScript seleccionada

Dado MockFile implementando HasTokens com language = Unknown
Quando impure_core::check() for chamado
Então retorna vec[]
— lista vazia para Unknown, zero violações V4

Dado MockFile implementando HasWiringPurity com layer = L4
E declarations = [Declaration { kind: Enum, name: "Mode", line: 3 }]
Quando wiring_logic_leak::check() for chamado com WiringConfig::default()
Então retorna Violation V12 Warning

Dado MockFile implementando HasImports com layer = L1
E imports = [Import { target_layer: Layer::Lab, line: 7, .. }]
Quando quarantine_leak::check() for chamado
Então retorna Violation V10 Fatal
— HasImports reutilizada para V10, filtragem por target_layer

Dado MockFile implementando HasImports
Com Import { kind: ImportKind::Named, target_layer: Layer::L3 }
em arquivo com layer = L2
Quando forbidden_import::check() for chamado
Então retorna Violation V3
— V3 usa target_layer, nunca ImportKind
```

---

## Histórico de Revisões

| Data | Motivo | Arquivos afetados |
|------|--------|-------------------|
| 2026-10-16 | Define alternativas escritas de V19, grupos aninhados, sentinela e saturação; distingue combinações e cobertura | rule_traits.rs |
| 2026-03-15 | Criação (ADR-0006 refactor): traits movidas de rules/ para contracts/ para corrigir inversão entities→rules em parsed_file.rs | rule_traits.rs |
| 2026-03-16 | ADR-0007: HasWiringPurity adicionada para V12; nota sobre V3/V9/V10 partilhando HasImports | rule_traits.rs |
| 2026-03-16 | ADR-0007 fecho: rule_traits.rs movido de contracts/ para entities/ | rule_traits.rs |
| 2026-03-18 | ADR-0009 correcção: HasTokens ganha language() para V4 multi-linguagem; nota sobre V4 nunca usar ImportKind; mock de V4 actualizado com campo language; critérios de Rust/Python/TypeScript/Unknown adicionados; critério V3 com ImportKind::Named documenta agnósticidade | rule_traits.rs, impure_core.rs |
| 2026-08-24 | HasPromptFilesystem ganha layer() como oráculo único do escopo L1–L4 de V1 | rule_traits.rs, parsed_file.rs, prompt_header.rs |
| 2026-08-24 | Taxonomia pública V23–V25 documentada; DirectDecisionReimplementation fecha a quarta modalidade sem colapsá-la em proxy/canonicalizer | rule_traits.rs, decision_ownership.rs |
| 2026-08-24 | IR V21 vinculada à porta pura de frescura; filesystem permanece fora de entities/rules | rule_traits.rs, citation_freshness.rs, unsourced_constant.rs |
