# Alternativas para Evitar iniciar software do zero quando projetos, componentes ou padrões reutilizáveis já resolvem toda ou parte da ideia, produzindo uma decisão de partida baseada em evidências.

Fonte canônica: [alternatives.json](alternatives.json)

## Alternativas

| Repositório | Fit | Cobertura | Estrelas | Licença |
|---|---:|---:|---:|---|

## Excluídos

| Repositório | Fit | Razões e bloqueios |
|---|---:|---|
| `local/bateia-a061b61e@02ef119467e1ea02d05d567d2db87273d4f4d1bc4ea3377253f726a8815b1127` | INCONCLUSIVE | alinhamento do problema inconclusivo; cobertura comprovada: 0/10; licença não reconhecida; valide os termos antes da adoção; manutenção inconclusiva; operação local inconclusiva |
