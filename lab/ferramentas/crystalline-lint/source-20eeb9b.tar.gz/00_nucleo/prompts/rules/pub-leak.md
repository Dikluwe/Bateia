# Prompt: Rule V9 - Pub Leak (pub-leak)
Hash do Código: eff86053

**Camada**: L1 (Core — Rules)
**Regra**: V9
**Criado em**: 2026-03-14 (ADR-0006)
**Arquivos gerados**:
  - 01_core/rules/pub_leak.rs + test

---

## Contexto

V3 garante a direção do fluxo de dependência — L2 não importa
L3. Mas não garante a granularidade. Um agente pressionado pelo
compilador Rust adiciona `pub` a helpers internos de L1, e L2
passa a depender de detalhes de implementação que nunca deveriam
ser visíveis externamente.

V9 garante que imports de L2 e L3 em L1 usem apenas
subdiretórios explicitamente designados como portas públicas.

---

## Portas de L1

Declaradas em `crystalline.toml`:
```toml
[l1_ports]
entities  = "01_core/entities"
contracts = "01_core/contracts"
rules     = "01_core/rules"
```

Qualquer subdiretório de L1 não listado aqui é interno —
inacessível de L2 ou L3 mesmo que seus símbolos sejam `pub`.

---

## Especificação

V9 opera sobre `ParsedFile.imports`, inspecionando
`import.target_subdir` para imports com `target_layer == L1`:
```rust
pub fn check<'a>(file: &ParsedFile<'a>, ports: &L1Ports) -> Vec<Violation<'a>> {
    if !matches!(file.layer, Layer::L2 | Layer::L3) {
        return vec![];
    }

    file.imports.iter()
        .filter(|import| import.target_layer == Layer::L1)
        .filter_map(|import| {
            import.target_subdir
                .filter(|subdir| !ports.contains(subdir))
                .map(|subdir| (import, subdir))
        })
        .map(|(import, target_subdir)| Violation {
            rule_id: "V9".to_string(),
            level: ViolationLevel::Error,
            message: format!(
                "Vazamento de encapsulamento: '{}' importa '{}' \
                 de subdiretório interno de L1 '{}'. \
                 Use apenas as portas declaradas em [l1_ports].",
                file.path.display(),
                import.path,
                target_subdir
            ),
            location: Location {
                path: Cow::Borrowed(file.path),
                line: import.line,
                column: 0,
            },
        })
        .collect()
}
```

A mensagem preserva literalmente tanto `import.path` quanto o `target_subdir`
rejeitado que participou da decisão. Nenhum dos dois é inferido ou normalizado:
caixa, Unicode, NFC/NFD, prefixos e string vazia permanecem identidades distintas.
`target_subdir = None` continua isento e não recebe placeholder nem diagnóstico.

`L1Ports` é injetado via L4 — lido de `crystalline.toml` por L3
e passado como parâmetro. V9 nunca lê o toml diretamente.

---

## Campo adicional em `Import`
```rust
pub struct Import<'a> {
    pub path: &'a str,
    pub line: usize,
    pub kind: ImportKind,
    pub target_layer: Layer,
    pub target_subdir: Option<&'a str>, // novo — ADR-0006
    // None para crates externas (Layer::Unknown)
    // Some("entities") para crate::entities::*
    // Some("internal") para crate::internal::*
}
```

Resolvido por L3 (RustParser) via mapeamento de `[layers]` e
`[l1_ports]` em `crystalline.toml`. V9 em L1 apenas compara.

---

## Restrições (L1 Pura)

- Recebe `ParsedFile` e `&L1Ports` — zero I/O
- `L1Ports` é um conjunto de strings injetado por L4
- Não inspeciona visibilidade Rust (`pub`/`pub(crate)`) —
  inspeciona apenas o path do import
- Aplica-se apenas a L2 e L3 importando L1
- A evidência V9 inclui literalmente o import path e o `target_subdir` rejeitado
- Rule id, nível, localização, cardinalidade e ordem seguem inalterados

---

## Critérios de Verificação
```
Dado arquivo L2 com import crate::core::internal::helper
E "internal" não está em [l1_ports]
Quando V9::check() for chamado
Então retorna Violation V9 Error com linha do import

Dado arquivo L2 com import crate::entities::Layer
E "entities" está em [l1_ports]
Quando V9::check() for chamado
Então retorna vec![] — porta válida

Dado arquivo L3 com import crate::contracts::FileProvider
E "contracts" está em [l1_ports]
Quando V9::check() for chamado
Então retorna vec![] — porta válida

Dado arquivo L1 com qualquer import
Quando V9::check() for chamado
Então retorna vec![] — V9 não se aplica a L1

Dado arquivo L4 com import crate::core::internal::helper
Quando V9::check() for chamado
Então retorna vec![] — V9 não se aplica a L4
— L4 pode compor tudo, V3 protege os demais

Dado import de reqwest::Client em L2
Quando V9::check() for chamado
Então retorna vec![] — crate externa, target_subdir = None
```

---

## Fundamentação Teórica

1. **Assimetria entre Visibilidade Sintática e Encapsulamento Arquitetural:**
   * **Abi-Antoun & Aldrich (2008)** (*Static Conformance Checking of Runtime Architectural Structure*): Demonstram que modificadores de visibilidade providos por linguagens de programação (`pub`, `public`) são insuficientes para impor limites arquiteturais, pois a necessidade de exportar símbolos para o mesmo pacote/crate frequentemente expõe detalhes internos para camadas consumidoras. A regra V9 materializa essa barreira adicional ao auditar a rota de importação, impedindo que $L_2$ ou $L_3$ se acoplem a submódulos auxiliares de $L_1$.
2. **Restrição de Acesso por Portais e Fachadas (Can-Only-Access-Through):**
   * **Passos et al. (2010)** (*Static Architecture-Conformance Checking: An Illustrative Overview*): No modelo de restrições de arquitetura estática, o isolamento de subsistemas requer que a interação ocorra exclusivamente através de interfaces designadas (*portais/fachadas*). A verificação de V9 implementa essa restrição de forma funcional pura, validando se o `target_subdir` do import pertence ao conjunto `[l1_ports]` formalmente autorizado.

---

## Histórico de Revisões

| Data | Motivo | Arquivos afetados |
|------|--------|-------------------|
| 2026-03-14 | Criação inicial (ADR-0006) | pub_leak.rs |
| 2026-06-09 | 0061: param `check_test_imports` (default false) — guard pula imports test-origin (`#[cfg(test)]`) antes do filtro de subdir | pub_leak.rs |
| 2026-08-24 | Mensagem V9 passa a preservar literalmente o target_subdir rejeitado junto ao import path | pub_leak.rs |
