# Alternativas para asynchronous event processing

Fonte canônica: [alternatives.json](alternatives.json)

## Alternativas

| Repositório | Fit | Cobertura | Estrelas | Licença |
|---|---:|---:|---:|---|

## Excluídos

| Repositório | Fit | Razões e bloqueios |
|---|---:|---|
| `local/events-negated-102fcf91@4341c31621901cbef048ef197a18545da145740b72d73cff0f0e0f75d833f24e` | INCONCLUSIVE | cobertura comprovada: 0/1; manutenção inconclusiva |
