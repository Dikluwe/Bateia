package events
func EventProcessor(value string) string { return value }
