module example.org/events

go 1.25.0
