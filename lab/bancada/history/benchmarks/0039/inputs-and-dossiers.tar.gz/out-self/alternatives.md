# Alternativas para Evitar iniciar software do zero quando projetos, componentes ou padrões reutilizáveis já resolvem toda ou parte da ideia, produzindo uma decisão de partida baseada em evidências.

Fonte canônica: [alternatives.json](alternatives.json)

## Alternativas

| Repositório | Fit | Cobertura | Estrelas | Licença |
|---|---:|---:|---:|---|

## Excluídos

| Repositório | Fit | Razões e bloqueios |
|---|---:|---|
| `local/bateia-a061b61e@2a2fa92982720a1471838bdc84ac2c7af7517ccaaf356b639ace2060b484df78` | INCONCLUSIVE | alinhamento do problema inconclusivo; cobertura comprovada: 0/10; manutenção inconclusiva; operação local inconclusiva |
