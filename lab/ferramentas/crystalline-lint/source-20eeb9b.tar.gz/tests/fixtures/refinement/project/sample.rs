fn beta() {}
fn alpha() {}
