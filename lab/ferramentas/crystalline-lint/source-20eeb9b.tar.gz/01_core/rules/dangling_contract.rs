//! Crystalline Lineage
//! @prompt 00_nucleo/prompts/rules/dangling-contract.md
//! @prompt-hash 0dd35453
//! @layer L1
//! @updated 2026-03-23

use std::borrow::Cow;
use std::path::PathBuf;

use crate::entities::project_index::ProjectIndex;
use crate::entities::violation::{Location, Violation, ViolationLevel};

/// V11 — Dangling Contract.
///
/// Detecta traits públicas declaradas em L1/contracts/ que não têm
/// nenhum `impl Trait for Type` correspondente em L2 ou L3.
/// O circuito está aberto — nenhuma instância pode ser injetada em L4.
///
/// Opera sobre ProjectIndex após a fase Reduce do pipeline paralelo.
/// Comparação por nome simples da trait (limitação declarada no prompt).
///
/// Error — bloqueia CI. Sem exceções configuráveis.
pub fn check_dangling_contracts<'a>(
    index: &ProjectIndex<'a>,
    level: ViolationLevel,
) -> Vec<Violation<'a>> {
    let mut pending: Vec<_> = index
        .all_declared_traits
        .iter()
        .filter(|t| {
            !index.all_implemented_traits.contains(*t)
                && !index.all_blanket_impl_traits.contains(*t)
        })
        .copied()
        .collect();
    pending.sort_unstable();

    pending
        .into_iter()
        .map(|trait_name| Violation {
            rule_id: "V11".to_string(),
            level: level.clone(),
            message: format!(
                "Contrato sem implementação: trait '{}' declarada em \
                 L1/contracts/ não tem impl correspondente em L2 ou L3. \
                 O circuito está aberto — nenhuma instância pode ser injetada.",
                trait_name
            ),
            location: Location {
                path: Cow::Owned(PathBuf::from("01_core/contracts")),
                line: 0,
                column: 0,
            },
        })
        .collect()
}

// ── Tests ─────────────────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;
    use crate::entities::project_index::ProjectIndex;

    fn index_with(
        declared: &[&'static str],
        implemented: &[&'static str],
    ) -> ProjectIndex<'static> {
        let mut index = ProjectIndex::new();
        for t in declared {
            index.all_declared_traits.insert(t);
        }
        for t in implemented {
            index.all_implemented_traits.insert(t);
        }
        index
    }

    fn index_with_blanket(
        declared: &[&'static str],
        implemented: &[&'static str],
        blanket: &[&'static str],
    ) -> ProjectIndex<'static> {
        let mut index = index_with(declared, implemented);
        for t in blanket {
            index.all_blanket_impl_traits.insert(t);
        }
        index
    }

    #[test]
    fn declared_without_impl_returns_v11_error() {
        let index = index_with(&["FileProvider"], &[]);
        let violations = check_dangling_contracts(&index, ViolationLevel::Error);
        assert_eq!(violations.len(), 1);
        assert_eq!(violations[0].rule_id, "V11");
        assert_eq!(violations[0].level, ViolationLevel::Error);
        assert!(violations[0].message.contains("FileProvider"));
    }

    #[test]
    fn declared_with_impl_returns_no_violation() {
        let index = index_with(&["LanguageParser"], &["LanguageParser"]);
        assert!(check_dangling_contracts(&index, ViolationLevel::Error).is_empty());
    }

    #[test]
    fn all_implemented_returns_empty() {
        let index = index_with(
            &["FileProvider", "LanguageParser"],
            &["FileProvider", "LanguageParser"],
        );
        assert!(check_dangling_contracts(&index, ViolationLevel::Error).is_empty());
    }

    #[test]
    fn two_declared_one_missing_returns_one_violation() {
        let index = index_with(&["FileProvider", "LanguageParser"], &["FileProvider"]);
        let violations = check_dangling_contracts(&index, ViolationLevel::Error);
        assert_eq!(violations.len(), 1);
        assert!(violations[0].message.contains("LanguageParser"));
    }

    #[test]
    fn empty_declared_returns_no_violations() {
        let index = index_with(&[], &["FileProvider"]);
        assert!(check_dangling_contracts(&index, ViolationLevel::Error).is_empty());
    }

    #[test]
    fn violation_location_points_to_contracts_dir() {
        let index = index_with(&["PromptReader"], &[]);
        let violations = check_dangling_contracts(&index, ViolationLevel::Error);
        assert_eq!(violations[0].location.path.as_os_str(), "01_core/contracts");
        assert_eq!(violations[0].location.line, 0);
    }

    #[test]
    fn multiple_dangling_traits_produce_one_violation_each() {
        let index = index_with(&["TraitA", "TraitB", "TraitC"], &[]);
        assert_eq!(
            check_dangling_contracts(&index, ViolationLevel::Error).len(),
            3
        );
    }

    #[test]
    fn dangling_traits_are_ordered_by_native_string_order() {
        let index = index_with(&["zeta", "Árvore", "Trait", "trait", "A\u{301}"], &[]);
        let violations = check_dangling_contracts(&index, ViolationLevel::Error);
        let names: Vec<_> = violations
            .iter()
            .map(|violation| {
                violation
                    .message
                    .split_once("trait '")
                    .unwrap()
                    .1
                    .split_once('\'')
                    .unwrap()
                    .0
            })
            .collect();
        assert_eq!(names, vec!["A\u{301}", "Trait", "trait", "zeta", "Árvore"]);
    }

    #[test]
    fn insertion_order_does_not_change_complete_violation_vector() {
        let forward = index_with(&["Gamma", "Alpha", "Beta"], &[]);
        let reverse = index_with(&["Beta", "Alpha", "Gamma"], &[]);
        assert_eq!(
            check_dangling_contracts(&forward, ViolationLevel::Warning),
            check_dangling_contracts(&reverse, ViolationLevel::Warning)
        );
    }

    #[test]
    fn extra_implemented_without_declaration_is_not_violation() {
        // Traits implementadas sem declaração em contracts/ não disparam V11
        let index = index_with(&[], &["SomeAdapter"]);
        assert!(check_dangling_contracts(&index, ViolationLevel::Error).is_empty());
    }

    #[test]
    fn level_warning_propagates_to_violation() {
        let index = index_with(&["FileProvider"], &[]);
        let violations = check_dangling_contracts(&index, ViolationLevel::Warning);
        assert_eq!(violations[0].level, ViolationLevel::Warning);
    }

    // ── blanket_impl_traits (ADR-0015) ────────────────────────────────────────

    #[test]
    fn blanket_impl_satisfies_contract_no_violation() {
        // Trait declarada em L1, satisfeita APENAS por blanket impl em L2/L3.
        // Não deve disparar V11 — é o falso positivo que esta ADR corrige.
        let index = index_with_blanket(&["TrackedWorld"], &[], &["TrackedWorld"]);
        assert!(check_dangling_contracts(&index, ViolationLevel::Error).is_empty());
    }

    #[test]
    fn blanket_impl_only_for_unrelated_trait_still_violations_others() {
        // Blanket impl satisfaz TrackedWorld, mas FileProvider continua dangling.
        let index = index_with_blanket(&["TrackedWorld", "FileProvider"], &[], &["TrackedWorld"]);
        let violations = check_dangling_contracts(&index, ViolationLevel::Error);
        assert_eq!(violations.len(), 1);
        assert!(violations[0].message.contains("FileProvider"));
    }

    #[test]
    fn both_concrete_and_blanket_no_violations() {
        // Um contrato satisfeito por impl concreto e outro por blanket impl.
        let index = index_with_blanket(
            &["FileProvider", "TrackedWorld"],
            &["FileProvider"],
            &["TrackedWorld"],
        );
        assert!(check_dangling_contracts(&index, ViolationLevel::Error).is_empty());
    }
}
