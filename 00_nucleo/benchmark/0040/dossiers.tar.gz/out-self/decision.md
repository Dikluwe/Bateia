# Decisão de reúso: INCONCLUSIVE

Fonte canônica: [reuse-decision.json](reuse-decision.json)

## Razões

- `DEC-INCONCLUSIVE-001` : evidência obrigatória ou gate eliminatório permanece inconclusivo
- `DEC-EVIDENCE-0040` local/bateia-a061b61e@02ef119467e1ea02d05d567d2db87273d4f4d1bc4ea3377253f726a8815b1127: capacidade não comprovada: comparar cobertura funcional licença manutenção e operação; nenhuma regra versionada cobre esta capacidade
- `DEC-EVIDENCE-0040` local/bateia-a061b61e@02ef119467e1ea02d05d567d2db87273d4f4d1bc4ea3377253f726a8815b1127: capacidade não comprovada: comprovar capacidades em documentação manifestos código e testes; nenhuma regra versionada cobre esta capacidade
- `DEC-EVIDENCE-0040` local/bateia-a061b61e@02ef119467e1ea02d05d567d2db87273d4f4d1bc4ea3377253f726a8815b1127: capacidade não comprovada: decidir entre fork extend compose integrate reference build e inconclusive; nenhuma regra versionada cobre esta capacidade
- `DEC-EVIDENCE-0040` local/bateia-a061b61e@02ef119467e1ea02d05d567d2db87273d4f4d1bc4ea3377253f726a8815b1127: capacidade não comprovada: decompor uma ideia em capacidades e restrições rastreáveis; nenhuma regra versionada cobre esta capacidade
- `DEC-EVIDENCE-0040` local/bateia-a061b61e@02ef119467e1ea02d05d567d2db87273d4f4d1bc4ea3377253f726a8815b1127: capacidade não comprovada: descobrir projetos públicos privados ou locais por intenção funcional; nenhuma regra versionada cobre esta capacidade
- `DEC-EVIDENCE-0040` local/bateia-a061b61e@02ef119467e1ea02d05d567d2db87273d4f4d1bc4ea3377253f726a8815b1127: capacidade não comprovada: propor a menor composição de projetos para cobrir lacunas reais; nenhuma regra versionada cobre esta capacidade
- `DEC-EVIDENCE-0040` local/bateia-a061b61e@02ef119467e1ea02d05d567d2db87273d4f4d1bc4ea3377253f726a8815b1127: capacidade não comprovada: reconhecer capacidades já existentes no próprio projeto; nenhuma regra versionada cobre esta capacidade
- `DEC-EVIDENCE-0040` local/bateia-a061b61e@02ef119467e1ea02d05d567d2db87273d4f4d1bc4ea3377253f726a8815b1127: capacidade não comprovada: recuperar evidência faltante sem repetir coleta genérica; nenhuma regra versionada cobre esta capacidade
- `DEC-EVIDENCE-0040` local/bateia-a061b61e@02ef119467e1ea02d05d567d2db87273d4f4d1bc4ea3377253f726a8815b1127: capacidade não comprovada: rejeitar projetos lexicalmente parecidos e funcionalmente irrelevantes; nenhuma regra versionada cobre esta capacidade
- `DEC-EVIDENCE-0040` local/bateia-a061b61e@02ef119467e1ea02d05d567d2db87273d4f4d1bc4ea3377253f726a8815b1127: capacidade não comprovada: reproduzir julgamento offline com artefatos e commits congelados; coleta incompleta ou com falha; ausência não pode ser concluída
- `DEC-EVIDENCE-0040` local/bateia-a061b61e@02ef119467e1ea02d05d567d2db87273d4f4d1bc4ea3377253f726a8815b1127: licença não verificada: localizar documento de licença com autoridade no projeto
- `DEC-EVIDENCE-0040` local/bateia-a061b61e@02ef119467e1ea02d05d567d2db87273d4f4d1bc4ea3377253f726a8815b1127: manutenção não verificada: obter metadados datados de atividade e arquivamento
- `DEC-EVIDENCE-0040` local/bateia-a061b61e@02ef119467e1ea02d05d567d2db87273d4f4d1bc4ea3377253f726a8815b1127: operação local não verificada: examinar requisitos e instruções de execução
- `DEC-EVIDENCE-0040` local/bateia-a061b61e@02ef119467e1ea02d05d567d2db87273d4f4d1bc4ea3377253f726a8815b1127: relação com a intenção não verificada: nenhuma regra versionada cobre esta capacidade
- `DEC-EVIDENCE-0040` local/bateia-a061b61e@02ef119467e1ea02d05d567d2db87273d4f4d1bc4ea3377253f726a8815b1127: restrição não verificada: evidência vinculada a repo commit path e hash; restrição sem regra determinística específica
- `DEC-EVIDENCE-0040` local/bateia-a061b61e@02ef119467e1ea02d05d567d2db87273d4f4d1bc4ea3377253f726a8815b1127: restrição não verificada: falha ou opacidade não pode virar ausência ou build; restrição sem regra determinística específica
- `DEC-EVIDENCE-0040` local/bateia-a061b61e@02ef119467e1ea02d05d567d2db87273d4f4d1bc4ea3377253f726a8815b1127: restrição não verificada: non_goal: buscar somente por palavras iguais; coleta incompleta
- `DEC-EVIDENCE-0040` local/bateia-a061b61e@02ef119467e1ea02d05d567d2db87273d4f4d1bc4ea3377253f726a8815b1127: restrição não verificada: non_goal: copiar código de concorrentes; coleta incompleta
- `DEC-EVIDENCE-0040` local/bateia-a061b61e@02ef119467e1ea02d05d567d2db87273d4f4d1bc4ea3377253f726a8815b1127: restrição não verificada: non_goal: gerar código automaticamente; coleta incompleta
- `DEC-EVIDENCE-0040` local/bateia-a061b61e@02ef119467e1ea02d05d567d2db87273d4f4d1bc4ea3377253f726a8815b1127: restrição não verificada: non_goal: ranquear apenas por estrelas; coleta incompleta
- `DEC-EVIDENCE-0040` local/bateia-a061b61e@02ef119467e1ea02d05d567d2db87273d4f4d1bc4ea3377253f726a8815b1127: restrição não verificada: non_goal: tratar jogo Katamari ou autofagia biológica como seleção de software; coleta incompleta
- `DEC-EVIDENCE-0040` local/bateia-a061b61e@02ef119467e1ea02d05d567d2db87273d4f4d1bc4ea3377253f726a8815b1127: restrição não verificada: replay offline; restrição operacional avaliada por regras locais
- `DEC-EVIDENCE-0040` local/bateia-a061b61e@02ef119467e1ea02d05d567d2db87273d4f4d1bc4ea3377253f726a8815b1127: restrição não verificada: sem LLM no pipeline principal; restrição sem regra determinística específica
- `DEC-EVIDENCE-0040` local/bateia-a061b61e@02ef119467e1ea02d05d567d2db87273d4f4d1bc4ea3377253f726a8815b1127: restrição não verificada: suporte a repositórios puramente locais; restrição sem regra determinística específica

## Capacidades ainda não comprovadas

- comparar cobertura funcional licença manutenção e operação
- comprovar capacidades em documentação manifestos código e testes
- decidir entre fork extend compose integrate reference build e inconclusive
- decompor uma ideia em capacidades e restrições rastreáveis
- descobrir projetos públicos privados ou locais por intenção funcional
- propor a menor composição de projetos para cobrir lacunas reais
- reconhecer capacidades já existentes no próprio projeto
- recuperar evidência faltante sem repetir coleta genérica
- rejeitar projetos lexicalmente parecidos e funcionalmente irrelevantes
- reproduzir julgamento offline com artefatos e commits congelados

## Evidências

Consulte [assessment-report.json](assessment-report.json) e [evidence/bundles.json](evidence/bundles.json).
